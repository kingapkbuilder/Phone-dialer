import React, { useState, useEffect, useRef } from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Pause,
  Play,
  FileText,
  Grid,
  Disc3,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';
import { Contact, RecordSettings, Language } from '../types/dialer';
import { soundFx } from '../utils/audioSynthesizer';
import { CallAudioRecorder, RecordedAudioResult } from '../utils/soundRecorder';
import { TRANSLATIONS } from '../utils/translations';

interface ActiveCallScreenProps {
  number: string;
  contact?: Contact;
  simSlot: 1 | 2;
  recordSettings: RecordSettings;
  language: Language;
  onEndCall: (result: {
    durationSeconds: number;
    recordedAudio?: RecordedAudioResult;
    callNotes: string;
    isSpam?: boolean;
  }) => void;
}

export const ActiveCallScreen: React.FC<ActiveCallScreenProps> = ({
  number,
  contact,
  simSlot,
  recordSettings,
  language,
  onEndCall,
}) => {
  const [callState, setCallState] = useState<'connecting' | 'ringing' | 'connected'>('connecting');
  const [callDuration, setCallDuration] = useState<number>(0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isSpeaker, setIsSpeaker] = useState<boolean>(false);
  const [isOnHold, setIsOnHold] = useState<boolean>(false);
  const [showNotesModal, setShowNotesModal] = useState<boolean>(false);
  const [callNotes, setCallNotes] = useState<string>('');
  const [isRecordingActive, setIsRecordingActive] = useState<boolean>(false);
  const [showKeypadOverlay, setShowKeypadOverlay] = useState<boolean>(false);
  const [keypadInput, setKeypadInput] = useState<string>('');

  const recorderRef = useRef<CallAudioRecorder | null>(null);
  const timerRef = useRef<number | null>(null);
  const stopRingRef = useRef<(() => void) | null>(null);
  const t = TRANSLATIONS[language];

  // Determine if this call should auto-record
  const shouldAutoRecord = () => {
    if (contact?.autoRecord) return true;
    if (recordSettings.autoRecordAll) return true;
    if (recordSettings.autoRecordUnknown && !contact) return true;
    if (
      recordSettings.autoRecordSelectedOnly &&
      contact &&
      recordSettings.selectedContactIds.includes(contact.id)
    ) {
      return true;
    }
    return false;
  };

  // Lifecycle: Connecting -> Ringing -> Connected
  useEffect(() => {
    // Start ring tone
    const stopRing = soundFx.playCallRingTone();
    stopRingRef.current = stopRing;

    const ringTimer = setTimeout(() => {
      setCallState('ringing');
    }, 1200);

    const connectTimer = setTimeout(async () => {
      if (stopRingRef.current) stopRingRef.current();
      setCallState('connected');

      // Check auto recording
      if (shouldAutoRecord()) {
        const recorder = new CallAudioRecorder();
        recorderRef.current = recorder;
        await recorder.startRecording();
        setIsRecordingActive(true);

        if (!recordSettings.silentMode) {
          soundFx.playRecordBeep();
        }
      }
    }, 3200);

    return () => {
      clearTimeout(ringTimer);
      clearTimeout(connectTimer);
      if (stopRingRef.current) stopRingRef.current();
    };
  }, []);

  // Duration Timer
  useEffect(() => {
    if (callState === 'connected' && !isOnHold) {
      timerRef.current = window.setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [callState, isOnHold]);

  const handleEndCall = async () => {
    soundFx.playCallEndTone();
    if (stopRingRef.current) stopRingRef.current();

    let recordedResult: RecordedAudioResult | undefined;
    if (recorderRef.current && isRecordingActive) {
      try {
        recordedResult = await recorderRef.current.stopRecording();
      } catch (err) {
        console.error('Failed to stop recording cleanly', err);
      }
    }

    onEndCall({
      durationSeconds: callDuration,
      recordedAudio: recordedResult,
      callNotes,
      isSpam: number.startsWith('+91 140') || number.includes('7701'),
    });
  };

  const formatDuration = (secs: number) => {
    const m = Math.floor(secs / 60)
      .toString()
      .padStart(2, '0');
    const s = (secs % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  };

  const handleDtmfInput = (digit: string) => {
    soundFx.playDtmf(digit);
    setKeypadInput((prev) => prev + digit);
  };

  return (
    <div className="relative flex flex-col h-full justify-between bg-gradient-to-b from-slate-900 via-slate-950 to-black p-6 select-none overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-72 h-72 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Top Header & Caller Profile */}
      <div className="flex flex-col items-center pt-6 z-10">
        {/* SIM Indicator */}
        <div className="flex items-center space-x-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/60 text-[11px] text-slate-300 mb-6">
          <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
          <span>
            SIM {simSlot} ({simSlot === 1 ? 'Jio 5G' : 'Airtel 5G'}) • VoNR HD+
          </span>
        </div>

        {/* Contact Avatar / Pulse Animation */}
        <div className="relative mb-4">
          {callState === 'ringing' && (
            <div className="absolute inset-0 rounded-full border border-cyan-400 animate-ping opacity-30"></div>
          )}
          <div
            className={`w-28 h-28 rounded-full ${
              contact?.avatarColor || 'bg-slate-700'
            } flex items-center justify-center text-white text-3xl font-bold shadow-2xl ring-4 ring-slate-800/80`}
          >
            {contact?.name ? contact.name.charAt(0) : number.slice(-1) || 'U'}
          </div>
        </div>

        {/* Contact Name & Number */}
        <h2 className="text-xl sm:text-2xl font-bold text-white text-center tracking-tight max-w-xs truncate">
          {contact?.name || t.unknownCaller}
        </h2>
        <p className="font-mono text-sm text-slate-400 mt-0.5 tracking-wider">{number}</p>

        {/* Call Status / Live Duration */}
        <div className="mt-3">
          {callState === 'connecting' && (
            <span className="text-xs font-semibold text-cyan-400 animate-pulse tracking-wide">
              Connecting via 5G network...
            </span>
          )}
          {callState === 'ringing' && (
            <span className="text-xs font-semibold text-emerald-400 animate-pulse tracking-wide">
              Ringing...
            </span>
          )}
          {callState === 'connected' && (
            <div className="flex flex-col items-center">
              <span className="font-mono text-lg font-bold text-white tracking-widest">
                {formatDuration(callDuration)}
              </span>
              {isOnHold && (
                <span className="text-[11px] text-amber-400 font-semibold mt-0.5">
                  Call on Hold
                </span>
              )}
            </div>
          )}
        </div>

        {/* Auto Call Recording Status Pill (HyperOS 2.0.5.0 India Zero-Warning feature) */}
        {isRecordingActive && (
          <div className="mt-4 flex items-center space-x-2 bg-emerald-950/80 border border-emerald-500/50 px-3 py-1 rounded-full shadow-lg backdrop-blur-md">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            <Disc3 className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
            <span className="text-[11px] font-bold text-emerald-200 tracking-wider">
              HYPEROS 2.0.5.0 SILENT REC (0% WARNING)
            </span>
            <span className="text-[10px] text-emerald-300 font-mono font-bold">
              {formatDuration(callDuration)}
            </span>
          </div>
        )}
      </div>

      {/* In-Call Keypad Overlay if opened */}
      {showKeypadOverlay && (
        <div className="z-20 my-2 bg-slate-900/95 border border-slate-700/80 p-3 rounded-2xl shadow-2xl backdrop-blur-md max-w-xs mx-auto w-full">
          <div className="flex justify-between items-center mb-2 px-1">
            <span className="text-xs font-mono text-cyan-300 truncate">
              DTMF: {keypadInput || 'Press numbers'}
            </span>
            <button
              onClick={() => setShowKeypadOverlay(false)}
              className="text-xs text-slate-400 hover:text-white"
            >
              Close
            </button>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((d) => (
              <button
                key={d}
                onClick={() => handleDtmfInput(d)}
                className="h-10 rounded-xl bg-slate-800 text-white font-bold text-sm hover:bg-slate-700 active:bg-cyan-600 transition"
              >
                {d}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Call Actions Grid */}
      <div className="z-10 max-w-xs mx-auto w-full">
        <div className="grid grid-cols-3 gap-y-4 gap-x-6 mb-8 text-center">
          {/* Mute */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setIsMuted(!isMuted)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                isMuted
                  ? 'bg-amber-500 text-slate-950 font-bold shadow-lg shadow-amber-500/20'
                  : 'bg-slate-800/80 text-white hover:bg-slate-700'
              }`}
            >
              {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </button>
            <span className="text-[11px] text-slate-300 mt-1 font-medium">{t.mute}</span>
          </div>

          {/* Keypad */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setShowKeypadOverlay(!showKeypadOverlay)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                showKeypadOverlay
                  ? 'bg-cyan-500 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-white hover:bg-slate-700'
              }`}
            >
              <Grid className="w-6 h-6" />
            </button>
            <span className="text-[11px] text-slate-300 mt-1 font-medium">{t.keypad}</span>
          </div>

          {/* Speaker */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setIsSpeaker(!isSpeaker)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                isSpeaker
                  ? 'bg-cyan-500 text-slate-950 font-bold shadow-lg shadow-cyan-500/20'
                  : 'bg-slate-800/80 text-white hover:bg-slate-700'
              }`}
            >
              {isSpeaker ? <Volume2 className="w-6 h-6" /> : <VolumeX className="w-6 h-6" />}
            </button>
            <span className="text-[11px] text-slate-300 mt-1 font-medium">{t.speaker}</span>
          </div>

          {/* Hold */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setIsOnHold(!isOnHold)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                isOnHold
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-800/80 text-white hover:bg-slate-700'
              }`}
            >
              {isOnHold ? <Play className="w-6 h-6" /> : <Pause className="w-6 h-6" />}
            </button>
            <span className="text-[11px] text-slate-300 mt-1 font-medium">{t.hold}</span>
          </div>

          {/* Call Recording Toggle */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setIsRecordingActive(!isRecordingActive)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                isRecordingActive
                  ? 'bg-red-500 text-white shadow-lg shadow-red-500/30'
                  : 'bg-slate-800/80 text-slate-400 hover:text-white'
              }`}
            >
              <Disc3 className={`w-6 h-6 ${isRecordingActive ? 'animate-spin' : ''}`} />
            </button>
            <span className="text-[11px] text-slate-300 mt-1 font-medium">
              {isRecordingActive ? 'Recording' : 'Record'}
            </span>
          </div>

          {/* Call Notes */}
          <div className="flex flex-col items-center">
            <button
              type="button"
              onClick={() => setShowNotesModal(true)}
              className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${
                callNotes.trim()
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-800/80 text-white hover:bg-slate-700'
              }`}
            >
              <FileText className="w-6 h-6" />
            </button>
            <span className="text-[11px] text-slate-300 mt-1 font-medium">{t.notes}</span>
          </div>
        </div>

        {/* End Call Button */}
        <div className="flex justify-center pb-2">
          <button
            type="button"
            onClick={handleEndCall}
            className="w-18 h-18 rounded-full bg-red-600 hover:bg-red-500 active:scale-90 text-white flex items-center justify-center shadow-xl shadow-red-600/40 transition-all cursor-pointer ring-4 ring-red-900/40"
          >
            <PhoneOff className="w-8 h-8 fill-current" />
          </button>
        </div>
      </div>

      {/* Call Notes Modal */}
      {showNotesModal && (
        <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-sm w-full shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold text-white text-sm flex items-center space-x-1.5">
                <FileText className="w-4 h-4 text-cyan-400" />
                <span>Call Quick Notes</span>
              </h3>
              <button
                onClick={() => setShowNotesModal(false)}
                className="text-xs text-slate-400 hover:text-white"
              >
                Close
              </button>
            </div>
            <textarea
              value={callNotes}
              onChange={(e) => setCallNotes(e.target.value)}
              placeholder="e.g. Discussed order discount, call back tomorrow at 4 PM..."
              rows={4}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none font-sans"
            />
            <div className="mt-3 flex justify-end">
              <button
                type="button"
                onClick={() => setShowNotesModal(false)}
                className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold rounded-lg"
              >
                Save to Call Log
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
