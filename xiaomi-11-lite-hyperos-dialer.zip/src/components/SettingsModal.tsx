import React from 'react';
import {
  X,
  Disc3,
  Volume2,
  VolumeX,
  Sliders,
  Smartphone,
  ShieldCheck,
  Languages,
  Check,
} from 'lucide-react';
import { RecordSettings, Language } from '../types/dialer';
import { TRANSLATIONS } from '../utils/translations';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: RecordSettings;
  onUpdateSettings: (settings: Partial<RecordSettings>) => void;
  language: Language;
  onSelectLanguage: (lang: Language) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
  language,
  onSelectLanguage,
}) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[language];

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4 select-none">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center space-x-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="font-bold text-white text-sm">MiDialer Pro Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Settings Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Section: Language Selection */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
              <Languages className="w-3.5 h-3.5 text-cyan-400" />
              <span>Language / भाषा / زبان</span>
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => onSelectLanguage('en')}
                className={`py-2 px-2 rounded-xl text-xs font-semibold border transition ${
                  language === 'en'
                    ? 'bg-cyan-600/30 border-cyan-500 text-cyan-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => onSelectLanguage('hi')}
                className={`py-2 px-2 rounded-xl text-xs font-semibold border transition ${
                  language === 'hi'
                    ? 'bg-cyan-600/30 border-cyan-500 text-cyan-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                हिंदी (Hindi)
              </button>
              <button
                type="button"
                onClick={() => onSelectLanguage('ur')}
                className={`py-2 px-2 rounded-xl text-xs font-semibold border transition ${
                  language === 'ur'
                    ? 'bg-cyan-600/30 border-cyan-500 text-cyan-200'
                    : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                اردو (Urdu)
              </button>
            </div>
          </div>

          {/* Section: Automatic Call Recording */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
              <Disc3 className="w-3.5 h-3.5 text-red-400" />
              <span>Auto Call Recorder Engine</span>
            </label>

            <div className="bg-slate-950 rounded-2xl border border-slate-800 divide-y divide-slate-850">
              {/* Auto Record All */}
              <div className="p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">Record All Calls Automatically</div>
                  <div className="text-[10px] text-slate-400">Records incoming & outgoing calls</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoRecordAll}
                  onChange={(e) => onUpdateSettings({ autoRecordAll: e.target.checked })}
                  className="w-4 h-4 accent-red-500 rounded cursor-pointer"
                />
              </div>

              {/* Auto Record Unknown */}
              <div className="p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">Auto-Record Unknown Numbers</div>
                  <div className="text-[10px] text-slate-400">Record unsaved contacts & spam calls</div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.autoRecordUnknown}
                  onChange={(e) => onUpdateSettings({ autoRecordUnknown: e.target.checked })}
                  className="w-4 h-4 accent-red-500 rounded cursor-pointer"
                />
              </div>

              {/* Silent Mode */}
              <div className="p-3 flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white flex items-center space-x-1">
                    <span>Silent Recording Mode</span>
                    <span className="text-[9px] bg-emerald-950 text-emerald-400 border border-emerald-800 px-1 rounded">
                      No Beep
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Does NOT announce "This call is being recorded"
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={settings.silentMode}
                  onChange={(e) => onUpdateSettings({ silentMode: e.target.checked })}
                  className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>

          {/* Section: Audio Quality & Format */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              Audio Format & Bitrate (For 128GB ROM)
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['standard', 'high', 'ultra'] as const).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => onUpdateSettings({ audioQuality: q })}
                  className={`py-2 px-1 text-center rounded-xl border transition ${
                    settings.audioQuality === q
                      ? 'bg-slate-800 border-red-500 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <div className="text-xs font-bold capitalize">{q}</div>
                  <div className="text-[9px] font-mono text-slate-400">
                    {q === 'standard' ? '64kbps' : q === 'high' ? '128kbps' : '256kbps'}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Section: Dual SIM Setup */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center space-x-1">
              <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Dual SIM Configuration</span>
            </label>

            <div className="bg-slate-950 rounded-2xl border border-slate-800 p-3 space-y-2.5">
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">SIM 1 Label</label>
                <input
                  type="text"
                  value={settings.sim1Carrier}
                  onChange={(e) => onUpdateSettings({ sim1Carrier: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-400 block mb-1">SIM 2 Label</label>
                <input
                  type="text"
                  value={settings.sim2Carrier}
                  onChange={(e) => onUpdateSettings({ sim2Carrier: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white"
                />
              </div>
            </div>
          </div>

          {/* Section: DTMF Keypad Audio */}
          <div className="p-3 bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              {settings.dtmfSound ? (
                <Volume2 className="w-4 h-4 text-cyan-400" />
              ) : (
                <VolumeX className="w-4 h-4 text-slate-500" />
              )}
              <div>
                <div className="text-xs font-semibold text-white">Dialpad DTMF Key Sounds</div>
                <div className="text-[10px] text-slate-400">Play tone when pressing number keys</div>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.dtmfSound}
              onChange={(e) => onUpdateSettings({ dtmfSound: e.target.checked })}
              className="w-4 h-4 accent-cyan-500 rounded cursor-pointer"
            />
          </div>
        </div>

        {/* Footer Done Button */}
        <div className="p-3 bg-slate-950 border-t border-slate-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-bold transition shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
