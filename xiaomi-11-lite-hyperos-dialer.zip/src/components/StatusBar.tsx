import React, { useState, useEffect } from 'react';
import { Wifi, Battery } from 'lucide-react';

interface StatusBarProps {
  batteryLevel?: number;
  isRecording?: boolean;
}

export const StatusBar: React.FC<StatusBarProps> = ({ batteryLevel = 84, isRecording = false }) => {
  const [timeStr, setTimeStr] = useState<string>('12:20');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="relative w-full h-8 px-4 flex items-center justify-between text-xs font-semibold text-slate-200 select-none z-30 bg-slate-950/80 backdrop-blur-md">
      {/* Top Left Punch-hole Camera Characteristic of Xiaomi 11 Lite 5G NE (lisa) */}
      <div className="flex items-center space-x-2">
        {/* Punch hole camera dot */}
        <div className="w-3.5 h-3.5 rounded-full bg-black ring-1 ring-slate-800 shadow-inner flex items-center justify-center">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-900/60 ring-0.5 ring-cyan-500/40"></div>
        </div>
        <span className="font-mono text-[11px] tracking-tight text-slate-300 font-bold ml-1">{timeStr}</span>
        {isRecording && (
          <div className="flex items-center space-x-1 bg-red-950/70 border border-red-500/40 px-1.5 py-0.5 rounded-full animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-red-500"></span>
            <span className="text-[9px] text-red-300 font-bold tracking-wider">REC</span>
          </div>
        )}
      </div>

      {/* Network & Battery on the right */}
      <div className="flex items-center space-x-2 text-[10px] text-slate-300">
        <div className="flex items-center space-x-0.5 text-cyan-400 font-bold tracking-tighter">
          <span>5G</span>
          <span className="text-[8px] bg-cyan-950/80 px-1 py-0.2 rounded border border-cyan-800/60 text-cyan-300">VoNR</span>
        </div>
        
        {/* Signal Bars */}
        <div className="flex items-end space-x-0.5 h-3">
          <span className="w-0.5 h-1 bg-slate-200 rounded-sm"></span>
          <span className="w-0.5 h-1.5 bg-slate-200 rounded-sm"></span>
          <span className="w-0.5 h-2 bg-slate-200 rounded-sm"></span>
          <span className="w-0.5 h-2.5 bg-slate-200 rounded-sm"></span>
        </div>

        <Wifi className="w-3 h-3 text-slate-200" />

        {/* Battery with percentage */}
        <div className="flex items-center space-x-1">
          <span className="font-mono text-[10px] font-medium">{batteryLevel}%</span>
          <div className="relative flex items-center">
            <Battery className="w-3.5 h-3.5 text-slate-200" />
            <div className="absolute left-[2.5px] top-[4.5px] h-[5px] w-[6px] bg-emerald-400 rounded-xs"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
