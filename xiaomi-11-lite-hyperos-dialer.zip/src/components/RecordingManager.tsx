import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Download,
  Share2,
  Trash2,
  FileAudio,
  Sparkles,
  HardDrive,
  Cpu,
  Clock,
  Mic,
  Disc3,
  FileText,
  Volume2,
} from 'lucide-react';
import { CallLog, Language } from '../types/dialer';
import { TRANSLATIONS } from '../utils/translations';
import { createSyntheticAudioBlob } from '../utils/soundRecorder';

interface RecordingManagerProps {
  logs: CallLog[];
  selectedLog?: CallLog | null;
  onSelectLog: (log: CallLog) => void;
  onDeleteLog: (id: string) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  language: Language;
}

export const RecordingManager: React.FC<RecordingManagerProps> = ({
  logs,
  selectedLog,
  onSelectLog,
  onDeleteLog,
  onUpdateNotes,
  language,
}) => {
  const recordedLogs = logs.filter((l) => l.isRecorded);
  const activeLog = selectedLog || recordedLogs[0] || null;

  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackTime, setPlaybackTime] = useState<number>(0);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [editingNotes, setEditingNotes] = useState<string>('');
  const [isEditingNotes, setIsEditingNotes] = useState<boolean>(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const t = TRANSLATIONS[language];

  // Storage calculation based on Xiaomi 11 Lite 5G NE 128GB ROM
  const totalSizeBytes = recordedLogs.reduce((acc, curr) => acc + (curr.recordingSizeBytes || 500000), 0);
  const totalSizeMb = (totalSizeBytes / (1024 * 1024)).toFixed(1);
  const totalDurationSecs = recordedLogs.reduce((acc, curr) => acc + (curr.recordingDurationSeconds || curr.durationSeconds || 0), 0);

  useEffect(() => {
    if (activeLog) {
      setEditingNotes(activeLog.notes || '');
      setIsPlaying(false);
      setPlaybackTime(0);

      // Ensure audio URL exists
      if (!activeLog.recordingUrl) {
        createSyntheticAudioBlob(activeLog.durationSeconds || 30).then((blob) => {
          activeLog.recordingUrl = URL.createObjectURL(blob);
          if (audioRef.current) {
            audioRef.current.src = activeLog.recordingUrl;
          }
        });
      } else if (audioRef.current) {
        audioRef.current.src = activeLog.recordingUrl;
      }
    }
  }, [activeLog?.id]);

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.playbackRate = playbackSpeed;
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch((e) => {
        console.warn('Playback error', e);
      });
    }
  };

  const handleTimeUpdate = () => {
    if (audioRef.current) {
      setPlaybackTime(audioRef.current.currentTime);
    }
  };

  const handleAudioEnded = () => {
    setIsPlaying(false);
    setPlaybackTime(0);
  };

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed);
    if (audioRef.current) {
      audioRef.current.playbackRate = speed;
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setPlaybackTime(val);
    if (audioRef.current) {
      audioRef.current.currentTime = val;
    }
  };

  const downloadAudioFile = (log: CallLog) => {
    if (!log.recordingUrl) return;
    const a = document.createElement('a');
    a.href = log.recordingUrl;
    a.download = `MiDialer_Recording_${(log.contactName || log.phoneNumber).replace(/\s+/g, '_')}_${Date.now()}.wav`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatSecs = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = Math.floor(s % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-hidden">
      {/* Hidden Audio Tag */}
      <audio
        ref={audioRef}
        onTimeUpdate={handleTimeUpdate}
        onEnded={handleAudioEnded}
      />

      {/* Top 128GB ROM Storage & Xiaomi 11 Lite 5G NE Stats Card */}
      <div className="p-3 bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-850 border-b border-slate-800">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center space-x-1.5 text-xs font-bold text-white">
            <HardDrive className="w-4 h-4 text-cyan-400" />
            <span>Xiaomi 11 Lite 5G NE (128GB ROM)</span>
          </div>
          <span className="text-[10px] font-mono bg-cyan-950/80 text-cyan-300 border border-cyan-800/60 px-2 py-0.5 rounded-full">
            {recordedLogs.length} Auto-Recordings
          </span>
        </div>

        {/* Storage Bar Indicator */}
        <div className="w-full bg-slate-950 h-2 rounded-full overflow-hidden flex border border-slate-800">
          <div className="bg-cyan-500 h-full" style={{ width: '58%' }} title="System & Apps"></div>
          <div className="bg-red-500 h-full" style={{ width: '4%' }} title="Call Recordings"></div>
          <div className="bg-slate-800 h-full" style={{ width: '38%' }} title="Free Space"></div>
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1.5 font-mono">
          <span className="text-cyan-300">📁 MIUI/sound_recorder/call_rec/</span>
          <span>Free Space: <strong className="text-emerald-400">54.2 GB / 128 GB</strong></span>
        </div>
        <div className="text-[10px] text-slate-400 mt-0.5 flex justify-between">
          <span>Total Size: <strong className="text-white font-mono">{totalSizeMb} MB</strong></span>
          <span className="text-emerald-400 font-semibold">● 0% Warning (Zero Audio Alert)</span>
        </div>
      </div>

      {recordedLogs.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-400">
          <Disc3 className="w-12 h-12 text-slate-700 animate-spin mb-3" />
          <h3 className="text-sm font-bold text-white">No Call Recordings Yet</h3>
          <p className="text-xs text-slate-500 max-w-xs mt-1">
            Calls made with "Auto-Record" turned ON will be saved here automatically with waveforms, transcripts, and audio playback.
          </p>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Active Player Deck */}
          {activeLog && (
            <div className="p-4 bg-slate-900/70 border-b border-slate-800 flex flex-col space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-sm text-white">
                      {activeLog.contactName || activeLog.phoneNumber}
                    </span>
                    <span className="text-[10px] bg-red-950/80 text-red-300 border border-red-500/40 px-1.5 py-0.2 rounded font-mono">
                      Silent REC
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5 font-mono">
                    {activeLog.phoneNumber} • {activeLog.timestamp}
                  </div>
                </div>

                <div className="flex items-center space-x-1.5">
                  <button
                    onClick={() => downloadAudioFile(activeLog)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                    title={t.downloadRecording}
                  >
                    <Download className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteLog(activeLog.id)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-400 transition"
                    title="Delete recording"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Dynamic Sound Waveform Canvas Representation */}
              <div className="h-10 w-full bg-slate-950/90 rounded-xl px-2 flex items-center justify-between border border-slate-800/80 overflow-hidden space-x-1">
                {Array.from({ length: 32 }).map((_, i) => {
                  const progress = playbackTime / (activeLog.durationSeconds || 30);
                  const isCurrent = i / 32 <= progress;
                  const heightPercent = 20 + Math.sin(i * 0.8) * 35 + ((i % 5) * 8);

                  return (
                    <span
                      key={i}
                      className={`w-1.5 rounded-full transition-all duration-150 ${
                        isCurrent
                          ? 'bg-gradient-to-t from-red-500 to-amber-400'
                          : 'bg-slate-700/60'
                      }`}
                      style={{ height: `${Math.max(15, Math.min(95, heightPercent))}%` }}
                    />
                  );
                })}
              </div>

              {/* Playback Scrubber & Time */}
              <div className="space-y-1">
                <input
                  type="range"
                  min="0"
                  max={activeLog.durationSeconds || 30}
                  step="0.1"
                  value={playbackTime}
                  onChange={handleSeek}
                  className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-red-500"
                />
                <div className="flex justify-between text-[10px] font-mono text-slate-400">
                  <span>{formatSecs(playbackTime)}</span>
                  <span>{formatSecs(activeLog.durationSeconds || 30)}</span>
                </div>
              </div>

              {/* Player Controls & Speed Selector */}
              <div className="flex items-center justify-between pt-1">
                {/* Speed buttons */}
                <div className="flex items-center space-x-1 bg-slate-950 px-2 py-1 rounded-lg border border-slate-800">
                  {[1, 1.25, 1.5, 2].map((spd) => (
                    <button
                      key={spd}
                      onClick={() => handleSpeedChange(spd)}
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded transition ${
                        playbackSpeed === spd
                          ? 'bg-cyan-500/20 text-cyan-300 font-bold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {spd}x
                    </button>
                  ))}
                </div>

                {/* Primary Play/Pause Button */}
                <button
                  type="button"
                  onClick={togglePlay}
                  className="w-12 h-12 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center shadow-lg shadow-red-600/30 active:scale-95 transition cursor-pointer"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 fill-current" />
                  ) : (
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  )}
                </button>

                {/* File size & format info */}
                <div className="text-right text-[10px] text-slate-400 font-mono">
                  <div>{activeLog.recordingSizeBytes ? `${(activeLog.recordingSizeBytes / 1024).toFixed(0)} KB` : '496 KB'}</div>
                  <div className="text-slate-500">AAC 128k (No Beep)</div>
                </div>
              </div>

              {/* Call Transcript & Smart Summary Box */}
              {(activeLog.transcription || activeLog.summary || activeLog.notes) && (
                <div className="mt-2 bg-slate-950/80 border border-slate-800 rounded-xl p-3 text-xs space-y-2">
                  <div className="flex items-center justify-between text-[11px] font-bold text-slate-200">
                    <span className="flex items-center space-x-1">
                      <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                      <span>{t.transcriptTitle}</span>
                    </span>
                  </div>

                  {activeLog.summary && (
                    <p className="text-slate-300 font-medium bg-cyan-950/30 p-2 rounded-lg border border-cyan-900/40 text-[11px]">
                      <strong>Summary:</strong> {activeLog.summary}
                    </p>
                  )}

                  {activeLog.transcription && (
                    <div className="text-[11px] text-slate-400 italic font-mono bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                      "{activeLog.transcription}"
                    </div>
                  )}

                  {/* Notes Edit */}
                  <div>
                    {isEditingNotes ? (
                      <div className="space-y-1.5 mt-1">
                        <textarea
                          value={editingNotes}
                          onChange={(e) => setEditingNotes(e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                          rows={2}
                        />
                        <div className="flex justify-end space-x-2">
                          <button
                            onClick={() => setIsEditingNotes(false)}
                            className="px-2 py-1 text-[10px] text-slate-400 hover:text-white"
                          >
                            Cancel
                          </button>
                          <button
                            onClick={() => {
                              onUpdateNotes(activeLog.id, editingNotes);
                              setIsEditingNotes(false);
                            }}
                            className="px-3 py-1 bg-cyan-600 text-white rounded text-[10px] font-semibold"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                        <span>Notes: {activeLog.notes || 'None'}</span>
                        <button
                          onClick={() => setIsEditingNotes(true)}
                          className="text-cyan-400 hover:underline text-[10px]"
                        >
                          Edit
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Recordings List */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-1">
              Recorded Call History
            </div>
            {recordedLogs.map((log) => {
              const isSelected = activeLog?.id === log.id;
              return (
                <div
                  key={log.id}
                  onClick={() => onSelectLog(log)}
                  className={`p-2.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-slate-850 border-red-500/60 shadow-md ring-1 ring-red-500/30'
                      : 'bg-slate-900/60 border-slate-800 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-center space-x-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-full bg-red-950/80 text-red-400 border border-red-500/30 flex items-center justify-center shrink-0">
                      <FileAudio className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-white truncate">
                        {log.contactName || log.phoneNumber}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {log.timestamp} • {formatSecs(log.durationSeconds)}
                      </div>
                    </div>
                  </div>

                  <div className="text-right text-[10px] font-mono text-slate-400 shrink-0">
                    <div>{log.recordingSizeBytes ? `${(log.recordingSizeBytes / 1024).toFixed(0)} KB` : '496 KB'}</div>
                    <div className="text-emerald-400">Recorded</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
