import React, { useState, useMemo } from 'react';
import { Phone, Delete, UserPlus, Sparkles, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { Contact, RecordSettings, Language } from '../types/dialer';
import { soundFx } from '../utils/audioSynthesizer';
import { TRANSLATIONS } from '../utils/translations';

interface DialpadProps {
  contacts: Contact[];
  onStartCall: (number: string, contact?: Contact, simSlot?: 1 | 2) => void;
  onAddContact: (number: string) => void;
  recordSettings: RecordSettings;
  language: Language;
}

const T9_KEYS = [
  { digit: '1', letters: '⚲' },
  { digit: '2', letters: 'ABC' },
  { digit: '3', letters: 'DEF' },
  { digit: '4', letters: 'GHI' },
  { digit: '5', letters: 'JKL' },
  { digit: '6', letters: 'MNO' },
  { digit: '7', letters: 'PQRS' },
  { digit: '8', letters: 'TUV' },
  { digit: '9', letters: 'WXYZ' },
  { digit: '*', letters: '(P)' },
  { digit: '0', letters: '+' },
  { digit: '#', letters: '(W)' },
];

export const Dialpad: React.FC<DialpadProps> = ({
  contacts,
  onStartCall,
  onAddContact,
  recordSettings,
  language,
}) => {
  const [inputNumber, setInputNumber] = useState<string>('');
  const t = TRANSLATIONS[language];

  // T9 Key Mapping for search
  const t9Map: Record<string, string> = {
    a: '2', b: '2', c: '2',
    d: '3', e: '3', f: '3',
    g: '4', h: '4', i: '4',
    j: '5', k: '5', l: '5',
    m: '6', n: '6', o: '6',
    p: '7', q: '7', r: '7', s: '7',
    t: '8', u: '8', v: '8',
    w: '9', x: '9', y: '9', z: '9',
  };

  // Find matching contacts dynamically
  const matchingContacts = useMemo(() => {
    if (!inputNumber.trim()) return [];
    const cleanInput = inputNumber.replace(/\D/g, '');

    return contacts.filter((c) => {
      const cleanPhone = c.number.replace(/\D/g, '');
      if (cleanPhone.includes(cleanInput)) return true;

      if (cleanInput.length >= 2) {
        const nameT9 = c.name
          .toLowerCase()
          .split('')
          .map((ch) => t9Map[ch] || '')
          .join('');
        if (nameT9.includes(cleanInput)) return true;
      }
      return false;
    }).slice(0, 3);
  }, [inputNumber, contacts]);

  const handleKeyPress = (digit: string) => {
    if (recordSettings.dtmfSound) {
      soundFx.playDtmf(digit);
    }
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(25);
    }
    setInputNumber((prev) => prev + digit);
  };

  const handleKeyLongPress = (digit: string) => {
    if (digit === '0') {
      setInputNumber((prev) => prev.slice(0, -1) + '+');
    }
  };

  const handleBackspace = () => {
    setInputNumber((prev) => prev.slice(0, -1));
  };

  const handleClearAll = () => {
    setInputNumber('');
  };

  const triggerCall = (sim: 1 | 2) => {
    if (!inputNumber.trim()) return;
    const match = contacts.find(
      (c) => c.number.replace(/\D/g, '') === inputNumber.replace(/\D/g, '')
    );
    onStartCall(inputNumber, match, sim);
  };

  return (
    <div className="flex flex-col h-full justify-between pb-2 select-none bg-slate-950">
      {/* Top Number Display Area with HyperOS T9 Match Overlay */}
      <div className="pt-2 px-4 flex flex-col justify-end min-h-[135px]">
        {/* Dynamic T9 Smart Match Results */}
        {matchingContacts.length > 0 && (
          <div className="mb-2 space-y-1.5 animate-in fade-in slide-in-from-top-1 duration-200">
            {matchingContacts.map((contact) => (
              <div
                key={contact.id}
                onClick={() => {
                  setInputNumber(contact.number);
                  onStartCall(contact.number, contact, 1);
                }}
                className="flex items-center justify-between px-3 py-2 bg-slate-900/95 hover:bg-slate-800 rounded-2xl cursor-pointer border border-slate-800 shadow-md transition-all"
              >
                <div className="flex items-center space-x-2.5">
                  <div className={`w-8 h-8 rounded-full ${contact.avatarColor} text-white flex items-center justify-center font-bold text-xs shadow-inner`}>
                    {contact.name.charAt(0)}
                  </div>
                  <div>
                    <div className="text-xs font-semibold text-white flex items-center space-x-1.5">
                      <span>{contact.name}</span>
                      <span className="text-[9px] bg-red-950 text-red-400 border border-red-500/30 px-1 py-0.2 rounded font-mono">
                        Auto-REC
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-400">{contact.number}</div>
                  </div>
                </div>
                <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Phone className="w-3.5 h-3.5" />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Input Number Display */}
        <div className="relative flex flex-col items-center justify-center min-h-[50px]">
          <div className="w-full text-center tracking-wider font-mono text-2xl sm:text-3xl font-bold text-white px-8 truncate selection:bg-cyan-500 selection:text-black">
            {inputNumber || (
              <span className="text-slate-600 text-sm font-normal tracking-normal">
                {t.dialPlaceholder}
              </span>
            )}
          </div>

          {/* Quick Action Badges */}
          {inputNumber && (
            <div className="flex items-center space-x-3 mt-1 text-xs text-slate-400">
              <button
                type="button"
                onClick={() => onAddContact(inputNumber)}
                className="flex items-center space-x-1 hover:text-cyan-400 transition-colors"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{t.addContact}</span>
              </button>
              <button
                type="button"
                onClick={handleClearAll}
                className="hover:text-red-400 transition-colors"
              >
                {t.clearPad}
              </button>
            </div>
          )}
        </div>

        {/* HyperOS 2.0.5.0 India Zero-Warning Status Banner */}
        <div className="flex items-center justify-center mt-1">
          <div className="inline-flex items-center space-x-1.5 bg-slate-900 border border-emerald-500/30 px-2.5 py-0.5 rounded-full text-[10px] text-emerald-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-semibold">
              HyperOS 2.0.5.0 Silent Auto-Record (0% Warning Sound)
            </span>
            <CheckCircle2 className="w-3 h-3 text-emerald-400 ml-0.5" />
          </div>
        </div>
      </div>

      {/* HyperOS Circular Keypad Grid */}
      <div className="px-5 py-1">
        <div className="grid grid-cols-3 gap-y-2.5 gap-x-5 max-w-xs mx-auto">
          {T9_KEYS.map((key) => (
            <button
              key={key.digit}
              type="button"
              onClick={() => handleKeyPress(key.digit)}
              onContextMenu={(e) => {
                e.preventDefault();
                handleKeyLongPress(key.digit);
              }}
              className="group relative flex flex-col items-center justify-center w-16 h-16 sm:w-18 sm:h-18 mx-auto rounded-full bg-slate-900/90 hover:bg-slate-800 active:bg-emerald-950/40 border border-slate-800/90 hover:border-slate-700 active:scale-95 transition-all shadow-md focus:outline-none"
            >
              <span className="text-xl sm:text-2xl font-bold text-white group-hover:text-emerald-300 group-active:text-emerald-400 transition-colors">
                {key.digit}
              </span>
              <span className="text-[9px] font-bold text-slate-400 group-hover:text-slate-300 tracking-widest mt-[-2px]">
                {key.letters}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Xiaomi HyperOS Dual SIM Calling Bar (India Layout) */}
      <div className="px-5 pt-1 pb-1">
        <div className="max-w-xs mx-auto flex items-center justify-between space-x-2">
          {/* SIM 1 (Jio 5G) Dial Button */}
          <button
            type="button"
            disabled={!inputNumber.trim()}
            onClick={() => triggerCall(1)}
            className={`flex-1 h-13 rounded-2xl flex items-center justify-center space-x-1.5 font-bold text-xs shadow-lg transition-all ${
              inputNumber.trim()
                ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30 active:scale-95 cursor-pointer ring-1 ring-emerald-400/50'
                : 'bg-slate-900 text-slate-600 cursor-not-allowed border border-slate-800'
            }`}
          >
            <Phone className="w-4 h-4 fill-current" />
            <div className="flex flex-col text-left leading-tight">
              <span className="text-[11px]">{recordSettings.sim1Carrier || 'Jio 5G'}</span>
              <span className="text-[9px] font-mono opacity-80">SIM 1</span>
            </div>
          </button>

          {/* SIM 2 (Airtel 5G) Dial Button */}
          <button
            type="button"
            disabled={!inputNumber.trim()}
            onClick={() => triggerCall(2)}
            className={`flex-1 h-13 rounded-2xl flex items-center justify-center space-x-1.5 font-bold text-xs shadow-lg transition-all ${
              inputNumber.trim()
                ? 'bg-teal-600 hover:bg-teal-500 text-white shadow-teal-600/30 active:scale-95 cursor-pointer ring-1 ring-teal-400/50'
                : 'bg-slate-900 text-slate-600 cursor-not-allowed border border-slate-800'
            }`}
          >
            <Phone className="w-4 h-4 fill-current" />
            <div className="flex flex-col text-left leading-tight">
              <span className="text-[11px]">{recordSettings.sim2Carrier || 'Airtel 5G'}</span>
              <span className="text-[9px] font-mono opacity-80">SIM 2</span>
            </div>
          </button>

          {/* Backspace Button */}
          <div className="w-11 flex items-center justify-center">
            {inputNumber ? (
              <button
                type="button"
                onClick={handleBackspace}
                className="w-11 h-11 rounded-full flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-850 active:scale-90 transition-all border border-slate-800"
              >
                <Delete className="w-5 h-5" />
              </button>
            ) : (
              <div className="w-11 h-11 flex items-center justify-center text-slate-700">
                <Sparkles className="w-4 h-4 text-slate-700" />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
