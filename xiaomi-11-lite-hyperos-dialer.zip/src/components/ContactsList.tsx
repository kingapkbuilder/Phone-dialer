import React, { useState } from 'react';
import {
  Search,
  Star,
  Phone,
  UserPlus,
  Trash2,
  Disc3,
  Edit2,
  Shield,
  Tag,
} from 'lucide-react';
import { Contact, Language } from '../types/dialer';
import { TRANSLATIONS } from '../utils/translations';

interface ContactsListProps {
  contacts: Contact[];
  onStartCall: (number: string, contact?: Contact, simSlot?: 1 | 2) => void;
  onToggleAutoRecord: (id: string) => void;
  onToggleStar: (id: string) => void;
  onDeleteContact: (id: string) => void;
  onSaveContact: (contact: Partial<Contact>) => void;
  language: Language;
}

export const ContactsList: React.FC<ContactsListProps> = ({
  contacts,
  onStartCall,
  onToggleAutoRecord,
  onToggleStar,
  onDeleteContact,
  onSaveContact,
  language,
}) => {
  const [search, setSearch] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);

  // Form fields
  const [formName, setFormName] = useState<string>('');
  const [formNumber, setFormNumber] = useState<string>('');
  const [formCategory, setFormCategory] = useState<'Personal' | 'Work' | 'Family' | 'Other'>('Personal');
  const [formAutoRecord, setFormAutoRecord] = useState<boolean>(true);
  const [formNote, setFormNote] = useState<string>('');

  const t = TRANSLATIONS[language];

  const filteredContacts = contacts.filter((c) => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    return c.name.toLowerCase().includes(q) || c.number.includes(q) || c.category?.toLowerCase().includes(q);
  });

  const sortedContacts = [...filteredContacts].sort((a, b) => {
    if (a.isStarred && !b.isStarred) return -1;
    if (!a.isStarred && b.isStarred) return 1;
    return a.name.localeCompare(b.name);
  });

  const handleOpenAdd = () => {
    setFormName('');
    setFormNumber('');
    setFormCategory('Personal');
    setFormAutoRecord(true);
    setFormNote('');
    setEditingContact(null);
    setShowAddModal(true);
  };

  const handleOpenEdit = (contact: Contact) => {
    setEditingContact(contact);
    setFormName(contact.name);
    setFormNumber(contact.number);
    setFormCategory(contact.category || 'Personal');
    setFormAutoRecord(!!contact.autoRecord);
    setFormNote(contact.note || '');
    setShowAddModal(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formNumber.trim()) return;

    onSaveContact({
      id: editingContact?.id,
      name: formName.trim(),
      number: formNumber.trim(),
      category: formCategory,
      autoRecord: formAutoRecord,
      note: formNote.trim(),
    });

    setShowAddModal(false);
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none">
      {/* Top Search & Add Contact Button */}
      <div className="p-3 border-b border-slate-900 bg-slate-900/60 backdrop-blur-md">
        <div className="flex items-center space-x-2">
          <div className="relative flex-1">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search contacts by name or phone..."
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            type="button"
            onClick={handleOpenAdd}
            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold flex items-center space-x-1 shadow-sm transition"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Add</span>
          </button>
        </div>
      </div>

      {/* Contact Cards List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {sortedContacts.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-slate-500 text-xs">
            <span>No contacts found.</span>
          </div>
        ) : (
          sortedContacts.map((contact) => (
            <div
              key={contact.id}
              className="group p-3 bg-slate-900/80 hover:bg-slate-850 border border-slate-800/80 rounded-xl transition-all shadow-xs flex items-center justify-between"
            >
              {/* Left Profile */}
              <div className="flex items-center space-x-3 min-w-0 flex-1">
                <div
                  className={`w-10 h-10 rounded-full ${contact.avatarColor} text-white font-bold text-sm flex items-center justify-center shrink-0 shadow`}
                >
                  {contact.name.charAt(0)}
                </div>

                <div className="min-w-0 flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="text-xs font-bold text-white truncate">{contact.name}</span>
                    {contact.isStarred && (
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-current shrink-0" />
                    )}
                  </div>
                  <div className="text-[11px] font-mono text-slate-400">{contact.number}</div>

                  {/* Auto-record & Category Badges */}
                  <div className="flex items-center space-x-1.5 mt-1">
                    {contact.autoRecord && (
                      <span className="text-[9px] bg-red-950/80 text-red-400 border border-red-500/40 px-1.5 py-0.2 rounded font-mono flex items-center space-x-0.5">
                        <Disc3 className="w-2.5 h-2.5" />
                        <span>Auto-REC</span>
                      </span>
                    )}
                    {contact.category && (
                      <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded">
                        {contact.category}
                      </span>
                    )}
                    {contact.note && (
                      <span className="text-[9px] text-slate-500 truncate max-w-[120px]">
                        • {contact.note}
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Right Action Buttons */}
              <div className="flex items-center space-x-1 shrink-0 ml-2">
                {/* Auto-Record Toggle Button */}
                <button
                  type="button"
                  onClick={() => onToggleAutoRecord(contact.id)}
                  className={`p-1.5 rounded-lg border transition ${
                    contact.autoRecord
                      ? 'bg-red-950/70 border-red-500/50 text-red-400 hover:bg-red-900/60'
                      : 'bg-slate-800/80 border-slate-700/60 text-slate-500 hover:text-slate-300'
                  }`}
                  title={contact.autoRecord ? 'Auto-recording active' : 'Turn on auto-recording'}
                >
                  <Disc3 className="w-3.5 h-3.5" />
                </button>

                {/* Star / Favorite */}
                <button
                  type="button"
                  onClick={() => onToggleStar(contact.id)}
                  className="p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-amber-400 transition"
                  title="Favorite"
                >
                  <Star className={`w-3.5 h-3.5 ${contact.isStarred ? 'text-amber-400 fill-current' : ''}`} />
                </button>

                {/* Edit */}
                <button
                  type="button"
                  onClick={() => handleOpenEdit(contact)}
                  className="p-1.5 rounded-lg bg-slate-800/80 text-slate-400 hover:text-white transition"
                  title="Edit contact"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>

                {/* Call Button */}
                <button
                  type="button"
                  onClick={() => onStartCall(contact.number, contact, 1)}
                  className="w-8 h-8 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center transition shadow-md shadow-emerald-500/20"
                  title="Call"
                >
                  <Phone className="w-3.5 h-3.5 fill-current" />
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add / Edit Contact Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleFormSubmit}
            className="bg-slate-900 border border-slate-800 rounded-2xl p-5 max-w-sm w-full shadow-2xl space-y-3"
          >
            <h3 className="font-bold text-white text-sm flex items-center space-x-1.5">
              <UserPlus className="w-4 h-4 text-cyan-400" />
              <span>{editingContact ? 'Edit Contact' : 'Create Contact'}</span>
            </h3>

            <div>
              <label className="text-[10px] text-slate-400 font-semibold block mb-1">Full Name</label>
              <input
                type="text"
                required
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="e.g. Sameer Khan"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-semibold block mb-1">Phone Number</label>
              <input
                type="tel"
                required
                value={formNumber}
                onChange={(e) => setFormNumber(e.target.value)}
                placeholder="+91 98201 00000"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-[10px] text-slate-400 font-semibold block mb-1">Category</label>
                <select
                  value={formCategory}
                  onChange={(e) => setFormCategory(e.target.value as any)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                >
                  <option value="Personal">Personal</option>
                  <option value="Work">Work</option>
                  <option value="Family">Family</option>
                  <option value="Other">Other</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] text-slate-400 font-semibold block mb-1">Call Recording</label>
                <label className="flex items-center space-x-2 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={formAutoRecord}
                    onChange={(e) => setFormAutoRecord(e.target.checked)}
                    className="accent-red-500 rounded"
                  />
                  <span className="text-xs text-red-300 font-medium">Auto-Record</span>
                </label>
              </div>
            </div>

            <div>
              <label className="text-[10px] text-slate-400 font-semibold block mb-1">Note (Optional)</label>
              <input
                type="text"
                value={formNote}
                onChange={(e) => setFormNote(e.target.value)}
                placeholder="e.g. VIP client, Xiaomi developer"
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
              />
            </div>

            <div className="flex justify-between items-center pt-2">
              {editingContact && (
                <button
                  type="button"
                  onClick={() => {
                    onDeleteContact(editingContact.id);
                    setShowAddModal(false);
                  }}
                  className="text-xs text-rose-400 hover:underline"
                >
                  Delete
                </button>
              )}
              <div className="flex space-x-2 ml-auto">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-xl text-xs font-semibold shadow-md"
                >
                  Save Contact
                </button>
              </div>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
