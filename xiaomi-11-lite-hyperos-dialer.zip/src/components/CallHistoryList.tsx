import React, { useState } from 'react';
import {
  PhoneIncoming,
  PhoneOutgoing,
  PhoneMissed,
  ShieldAlert,
  Play,
  Pause,
  Phone,
  Trash2,
  FileAudio,
  UserPlus,
  Sparkles,
  Info,
} from 'lucide-react';
import { CallLog, Contact, Language } from '../types/dialer';
import { TRANSLATIONS } from '../utils/translations';

interface CallHistoryListProps {
  logs: CallLog[];
  contacts: Contact[];
  onStartCall: (number: string, contact?: Contact, simSlot?: 1 | 2) => void;
  onSelectRecording: (log: CallLog) => void;
  onDeleteLog: (id: string) => void;
  onAddContact: (number: string) => void;
  language: Language;
}

export const CallHistoryList: React.FC<CallHistoryListProps> = ({
  logs,
  contacts,
  onStartCall,
  onSelectRecording,
  onDeleteLog,
  onAddContact,
  language,
}) => {
  const [filter, setFilter] = useState<'all' | 'missed' | 'recorded' | 'spam'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const t = TRANSLATIONS[language];

  const filteredLogs = logs.filter((log) => {
    // Filter type
    if (filter === 'missed' && log.type !== 'missed') return false;
    if (filter === 'recorded' && !log.isRecorded) return false;
    if (filter === 'spam' && !log.isSpam) return false;

    // Search query
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchName = log.contactName?.toLowerCase().includes(q);
      const matchPhone = log.phoneNumber.includes(q);
      const matchNotes = log.notes?.toLowerCase().includes(q);
      return matchName || matchPhone || matchNotes;
    }
    return true;
  });

  const getCallIcon = (type: CallLog['type'], isSpam?: boolean) => {
    if (isSpam) {
      return <ShieldAlert className="w-4 h-4 text-red-400" />;
    }
    switch (type) {
      case 'incoming':
        return <PhoneIncoming className="w-4 h-4 text-emerald-400" />;
      case 'outgoing':
        return <PhoneOutgoing className="w-4 h-4 text-cyan-400" />;
      case 'missed':
        return <PhoneMissed className="w-4 h-4 text-rose-500" />;
      default:
        return <PhoneIncoming className="w-4 h-4 text-slate-400" />;
    }
  };

  const formatDuration = (secs: number) => {
    if (secs === 0) return 'Missed';
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    if (m === 0) return `${s}s`;
    return `${m}m ${s}s`;
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none">
      {/* Top Filter Bar */}
      <div className="p-3 border-b border-slate-900 bg-slate-900/60 backdrop-blur-md">
        {/* Search Input */}
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search calls, numbers, or notes..."
          className="w-full bg-slate-950/80 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 mb-2.5"
        />

        {/* Filter Pills */}
        <div className="flex items-center space-x-1.5 overflow-x-auto pb-0.5">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'all'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.allCalls} ({logs.length})
          </button>
          <button
            onClick={() => setFilter('recorded')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all flex items-center space-x-1 ${
              filter === 'recorded'
                ? 'bg-red-500 text-white shadow-sm'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-red-400"></span>
            <span>{t.recordedCalls} ({logs.filter((l) => l.isRecorded).length})</span>
          </button>
          <button
            onClick={() => setFilter('missed')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'missed'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.missedCalls} ({logs.filter((l) => l.type === 'missed').length})
          </button>
          <button
            onClick={() => setFilter('spam')}
            className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
              filter === 'spam'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'bg-slate-800/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            {t.spamCalls}
          </button>
        </div>
      </div>

      {/* Call History Records */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-2">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-slate-500 text-xs">
            <Info className="w-8 h-8 text-slate-600 mb-2 stroke-1" />
            <span>No call logs match this filter.</span>
          </div>
        ) : (
          filteredLogs.map((log) => {
            const knownContact = contacts.find(
              (c) => c.number.replace(/\D/g, '') === log.phoneNumber.replace(/\D/g, '')
            );

            return (
              <div
                key={log.id}
                className="group p-3 bg-slate-900/80 hover:bg-slate-850 border border-slate-800/70 hover:border-slate-700 rounded-xl transition-all shadow-xs"
              >
                <div className="flex items-center justify-between">
                  {/* Left: Icon & Info */}
                  <div className="flex items-center space-x-3 min-w-0 flex-1">
                    <div className="w-9 h-9 rounded-full bg-slate-800 flex items-center justify-center shrink-0">
                      {getCallIcon(log.type, log.isSpam)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="font-semibold text-xs text-white truncate">
                          {log.contactName || log.phoneNumber}
                        </span>
                        <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-slate-800 text-slate-400">
                          SIM {log.simSlot}
                        </span>
                      </div>
                      <div className="flex items-center space-x-2 text-[11px] text-slate-400 mt-0.5">
                        <span className="font-mono">{log.timestamp}</span>
                        <span>•</span>
                        <span>{formatDuration(log.durationSeconds)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Right Actions: Call Back / Play Recording */}
                  <div className="flex items-center space-x-2 shrink-0">
                    {/* Auto-recording quick pill */}
                    {log.isRecorded && (
                      <button
                        type="button"
                        onClick={() => onSelectRecording(log)}
                        className="flex items-center space-x-1 px-2 py-1 bg-red-950/70 border border-red-500/40 hover:bg-red-900/80 rounded-lg text-red-300 text-[10px] font-medium transition cursor-pointer"
                        title="Open Recording"
                      >
                        <FileAudio className="w-3.5 h-3.5 text-red-400" />
                        <span>Play</span>
                      </button>
                    )}

                    {/* Quick Call */}
                    <button
                      type="button"
                      onClick={() => onStartCall(log.phoneNumber, knownContact, log.simSlot)}
                      className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-white flex items-center justify-center transition"
                      title="Call"
                    >
                      <Phone className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      type="button"
                      onClick={() => onDeleteLog(log.id)}
                      className="w-7 h-7 rounded-full text-slate-500 hover:text-rose-400 hover:bg-slate-800 flex items-center justify-center transition"
                      title="Delete"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Additional Note or Spam Label */}
                {log.isSpam && log.spamLabel && (
                  <div className="mt-2 text-[10px] text-amber-400/90 bg-amber-950/40 border border-amber-900/60 px-2 py-1 rounded-md">
                    ⚠️ {log.spamLabel}
                  </div>
                )}
                {log.notes && (
                  <div className="mt-2 text-[10px] text-slate-300 bg-slate-950/60 px-2 py-1 rounded-md border border-slate-800/60 font-sans">
                    💬 Note: {log.notes}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
