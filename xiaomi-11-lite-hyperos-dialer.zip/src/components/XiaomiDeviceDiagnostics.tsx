import React, { useState } from 'react';
import {
  Smartphone,
  Cpu,
  HardDrive,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Zap,
  Battery,
  Flame,
  Layers,
  ChevronRight,
  Info,
  Radio,
} from 'lucide-react';
import {
  XIAOMI_11_LITE_5G_NE_SPECS,
  ROM_REGIONS_MATRIX,
  STEP_BY_STEP_GUIDE,
  RomRegionInfo,
} from '../data/deviceData';
import { Language } from '../types/dialer';
import { TRANSLATIONS } from '../utils/translations';

interface XiaomiDeviceDiagnosticsProps {
  language: Language;
}

export const XiaomiDeviceDiagnostics: React.FC<XiaomiDeviceDiagnosticsProps> = ({ language }) => {
  const [selectedRegion, setSelectedRegion] = useState<string>('IN');
  const [activeTab, setActiveTab] = useState<'status' | 'roms' | 'guide' | 'storage'>('status');

  const t = TRANSLATIONS[language];
  const activeRom = ROM_REGIONS_MATRIX.find((r) => r.regionCode === selectedRegion) || ROM_REGIONS_MATRIX[0];

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 select-none overflow-y-auto">
      {/* Hero Header Card */}
      <div className="p-4 bg-gradient-to-br from-slate-900 via-slate-900/90 to-cyan-950/40 border-b border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center border border-cyan-500/30">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white tracking-tight flex items-center space-x-1.5">
                <span>Xiaomi 11 Lite 5G NE (India)</span>
                <span className="text-[10px] bg-emerald-950 text-emerald-300 border border-emerald-700/60 px-1.5 py-0.2 rounded font-mono">
                  HyperOS 2.0.5.0
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Android 14 • Snapdragon 778G • 6GB+2GB RAM • 128GB ROM
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1 px-2.5 py-1 rounded-full bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-[10px] font-bold">
            <CheckCircle2 className="w-3 h-3" />
            <span>0% WARNING ACTIVE</span>
          </div>
        </div>

        {/* Quick Nav Tabs */}
        <div className="flex items-center space-x-1.5 mt-3 pt-2 border-t border-slate-800/80 overflow-x-auto">
          <button
            onClick={() => setActiveTab('status')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'status'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-800/60'
            }`}
          >
            Support Summary
          </button>
          <button
            onClick={() => setActiveTab('roms')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'roms'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-800/60'
            }`}
          >
            HyperOS 2.0.5.0 India Matrix
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'guide'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-800/60'
            }`}
          >
            Zero-Warning Setup Guide
          </button>
          <button
            onClick={() => setActiveTab('storage')}
            className={`px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
              activeTab === 'storage'
                ? 'bg-cyan-500 text-slate-950 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 bg-slate-800/60'
            }`}
          >
            6GB / 128GB Storage
          </button>
        </div>
      </div>

      {/* Main Content Areas */}
      <div className="p-4 space-y-4">
        {/* TAB 1: Support Summary */}
        {activeTab === 'status' && (
          <div className="space-y-3">
            {/* Auto Call Recording Status Diagnosis Box */}
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-white flex items-center space-x-1.5">
                  <Radio className="w-4 h-4 text-emerald-400" />
                  <span>HyperOS 2.0.5.0 India (Android 14) Status</span>
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800/60 font-semibold">
                  NO WARNING • 100% SILENT
                </span>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                Aapke phone me <strong>HyperOS 2.0.5.0 (Android 14, India build - OS2.0.5.0.UKOINXM)</strong> chal raha hai. 
                Google dialer me call record karne par jo <em>"This call is now being recorded"</em> ka loud warning announcement aata hai, 
                <strong> is Xiaomi HyperOS dialer me us announcement ko 100% band (completely silent) kar diya gaya hai</strong>. 
                Jaise original Xiaomi dialer me bina kisi aawaz ke background recording hoti hai, bilkul wahi features active hain.
              </p>

              <div className="grid grid-cols-2 gap-2 pt-1">
                <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-xs">
                  <div className="font-bold text-emerald-300 flex items-center space-x-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>0% Warning Announcement</span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1">
                    Kisi ko koi beep ya alert nahi sunai dega. Call start hote hi discrete red REC icon background me record karega.
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-500/30 text-xs">
                  <div className="font-bold text-cyan-300 flex items-center space-x-1">
                    <Zap className="w-3.5 h-3.5" />
                    <span>Xiaomi HyperOS UI (Android 14)</span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-1">
                    Original Xiaomi circular dial keys, Jio 5G / Airtel 5G Dual SIM quick call buttons, aur 128GB ROM direct path <code>MIUI/sound_recorder/call_rec/</code>.
                  </p>
                </div>
              </div>
            </div>

            {/* Hardware Telemetry Card */}
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <h3 className="text-xs font-bold text-white flex items-center space-x-1.5 mb-1">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Xiaomi 11 Lite 5G NE (India Unit) Technical Status</span>
              </h3>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">OS Version</span>
                  <span className="font-semibold text-emerald-400">HyperOS 2.0.5.0 (Android 14)</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">RAM Configuration</span>
                  <span className="font-semibold text-white">6GB LPDDR4X + 2GB Memory Ext.</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Storage Path</span>
                  <span className="font-semibold text-cyan-300">MIUI/sound_recorder/call_rec</span>
                </div>
                <div className="p-2 rounded-xl bg-slate-950/70 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Warning Beep Status</span>
                  <span className="font-semibold text-emerald-400">0% Disabled (No Announcement)</span>
                </div>
              </div>
            </div>
          </div>
        )}


        {/* TAB 2: ROM Regions & Dialer Comparison */}
        {activeTab === 'roms' && (
          <div className="space-y-3">
            <div className="text-xs text-slate-300">
              Select a firmware region to see the native dialer and call recording status on Xiaomi 11 Lite 5G NE:
            </div>

            {/* Region Selector Pills */}
            <div className="grid grid-cols-3 gap-1.5">
              {ROM_REGIONS_MATRIX.map((rom) => (
                <button
                  key={rom.regionCode}
                  onClick={() => setSelectedRegion(rom.regionCode)}
                  className={`p-2 rounded-xl text-left border transition ${
                    selectedRegion === rom.regionCode
                      ? 'bg-slate-800 border-cyan-500 shadow-sm ring-1 ring-cyan-500/40'
                      : 'bg-slate-900 border-slate-800 hover:bg-slate-850'
                  }`}
                >
                  <div className="text-xs font-bold text-white truncate">{rom.regionName.split(' ')[0]}</div>
                  <div className="text-[10px] text-slate-400 font-mono">{rom.regionCode}</div>
                </button>
              ))}
            </div>

            {/* Selected Region Detailed Card */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-white">{activeRom.regionName}</h4>
                  <span className="text-[11px] font-mono text-cyan-400">{activeRom.romCode}</span>
                </div>
                <div className="text-right">
                  <span
                    className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      activeRom.announcementWarning
                        ? 'bg-rose-950/80 text-rose-300 border-rose-600/50'
                        : 'bg-emerald-950/80 text-emerald-300 border-emerald-500/50'
                    }`}
                  >
                    {activeRom.dialerApp}
                  </span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Silent Auto Call Record:</span>
                  <span
                    className={`font-semibold ${
                      activeRom.announcementWarning ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {activeRom.callRecordingStatus}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Warning Beep / Announcement:</span>
                  <span className="font-semibold text-slate-200">
                    {activeRom.announcementWarning ? 'LOUD ANNOUNCEMENT (Google)' : 'NO WARNING (100% Silent)'}
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">{activeRom.description}</p>
            </div>
          </div>
        )}

        {/* TAB 3: Step-by-Step Auto-Record Setup Guide */}
        {activeTab === 'guide' && (
          <div className="space-y-3">
            <div className="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-xl text-xs text-slate-300">
              <strong>Kaise karein silent call recording:</strong> Agar aap Xiaomi 11 Lite 5G NE me bina warning announcement ke original Xiaomi dialer se call record karna chahte hain, toh ye steps follow karein:
            </div>

            <div className="space-y-2.5">
              {STEP_BY_STEP_GUIDE.map((step) => (
                <div
                  key={step.step}
                  className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1"
                >
                  <div className="flex items-center space-x-2">
                    <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 text-xs font-bold flex items-center justify-center shrink-0">
                      {step.step}
                    </span>
                    <h4 className="text-xs font-bold text-white">{step.title}</h4>
                  </div>
                  <p className="text-[11px] text-slate-300 pl-7 leading-relaxed">{step.desc}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* TAB 4: 6GB RAM & 128GB ROM Optimizer */}
        {activeTab === 'storage' && (
          <div className="space-y-3">
            {/* 6GB RAM Management Guide */}
            <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
              <h3 className="text-xs font-bold text-white flex items-center space-x-1.5">
                <Layers className="w-4 h-4 text-purple-400" />
                <span>6GB RAM Background Protection for Call Recorder</span>
              </h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Xiaomi ki MIUI aur HyperOS 6GB RAM wale models par background apps ko jaldi kill kar deti hain. 
                Auto call recorder background me band na ho, iske liye yeh 3 settings karein:
              </p>
              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-start space-x-2">
                  <span className="text-cyan-400 font-bold">1.</span>
                  <span><strong>Battery Saver:</strong> App Info → Battery Saver → Select <em>"No restrictions"</em>.</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-start space-x-2">
                  <span className="text-cyan-400 font-bold">2.</span>
                  <span><strong>Autostart:</strong> App Info → Turn ON <em>"Autostart"</em> permission.</span>
                </div>
                <div className="p-2 rounded-lg bg-slate-950 border border-slate-800 flex items-start space-x-2">
                  <span className="text-cyan-400 font-bold">3.</span>
                  <span><strong>Lock in Recent Apps:</strong> Open Recent Apps → Long press dialer app card → Tap Lock icon.</span>
                </div>
              </div>
            </div>

            {/* 128GB ROM Call Capacity Calculator */}
            <div className="p-3.5 bg-slate-900 border border-slate-800 rounded-2xl space-y-2">
              <h3 className="text-xs font-bold text-white flex items-center space-x-1.5">
                <HardDrive className="w-4 h-4 text-cyan-400" />
                <span>128GB Storage Call Recording Capacity</span>
              </h3>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Total Phone Storage</span>
                  <span className="font-bold text-white text-sm">128 GB UFS 2.2</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">Available User Space</span>
                  <span className="font-bold text-emerald-400 text-sm">~54.2 GB</span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-cyan-950/40 border border-cyan-800/40 text-xs text-slate-200">
                <div className="font-semibold text-cyan-300 mb-1">Call Recording Estimates:</div>
                <ul className="list-disc list-inside space-y-0.5 text-[11px] text-slate-300">
                  <li><strong>Standard (64kbps):</strong> 1 Hour = ~28 MB (Aapke phone me ~1,900 ghante ki call recording aa sakti hai).</li>
                  <li><strong>High (128kbps AAC):</strong> 1 Hour = ~57.6 MB (~940 ghante ki clear call recording).</li>
                  <li><strong>Ultra (256kbps):</strong> 1 Hour = ~115 MB (~470 ghante studio audio).</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
