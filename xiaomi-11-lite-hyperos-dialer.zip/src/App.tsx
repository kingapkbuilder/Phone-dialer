import React, { useState } from 'react';
import {
  Phone,
  Clock,
  Users,
  Disc3,
  Smartphone,
  Settings,
  Languages,
  Maximize2,
  Minimize2,
  Sparkles,
  ShieldCheck,
  Radio,
  HelpCircle,
  Download,
} from 'lucide-react';

import {
  Contact,
  CallLog,
  RecordSettings,
  Language,
} from './types/dialer';
import { INITIAL_CONTACTS, INITIAL_CALL_LOGS } from './data/defaultContacts';
import { XIAOMI_11_LITE_5G_NE_SPECS } from './data/deviceData';
import { TRANSLATIONS } from './utils/translations';
import { StatusBar } from './components/StatusBar';
import { Dialpad } from './components/Dialpad';
import { ActiveCallScreen } from './components/ActiveCallScreen';
import { createInMemoryZip, downloadBlobClientSide } from './utils/zipGenerator';
import { CallHistoryList } from './components/CallHistoryList';
import { ContactsList } from './components/ContactsList';
import { RecordingManager } from './components/RecordingManager';
import { XiaomiDeviceDiagnostics } from './components/XiaomiDeviceDiagnostics';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  // Navigation & View state
  const [activeTab, setActiveTab] = useState<'keypad' | 'recents' | 'contacts' | 'recordings' | 'diagnostics'>('keypad');
  const [isPhoneFrameMode, setIsPhoneFrameMode] = useState<boolean>(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [language, setLanguage] = useState<Language>('hi'); // Defaulting to Hindi as user asked in Hindi/Urdu

  // Active Call State
  const [activeCall, setActiveCall] = useState<{
    number: string;
    contact?: Contact;
    simSlot: 1 | 2;
  } | null>(null);

  // Core Data
  const [contacts, setContacts] = useState<Contact[]>(INITIAL_CONTACTS);
  const [callLogs, setCallLogs] = useState<CallLog[]>(INITIAL_CALL_LOGS);
  const [selectedRecordingLog, setSelectedRecordingLog] = useState<CallLog | null>(null);

  // Settings State
  const [settings, setSettings] = useState<RecordSettings>({
    autoRecordAll: true,
    autoRecordUnknown: true,
    autoRecordSelectedOnly: false,
    selectedContactIds: ['c1', 'c2', 'c3', 'c5', 'c6'],
    silentMode: true, // No announcement warning
    audioFormat: 'aac',
    audioQuality: 'high',
    notifyOnCompleted: true,
    storageSavingMode: false,
    dtmfSound: true,
    sim1Carrier: 'Jio 5G',
    sim2Carrier: 'Airtel 5G',
    activeSim: 1,
  });

  const t = TRANSLATIONS[language];

  // Initiate call
  const handleStartCall = (number: string, contact?: Contact, simSlot: 1 | 2 = 1) => {
    setActiveCall({
      number,
      contact,
      simSlot,
    });
  };

  // End Call & record log
  const handleEndCall = ({
    durationSeconds,
    recordedAudio,
    callNotes,
    isSpam,
  }: {
    durationSeconds: number;
    recordedAudio?: any;
    callNotes: string;
    isSpam?: boolean;
  }) => {
    if (!activeCall) return;

    const newLogId = `log-${Date.now()}`;
    const newLog: CallLog = {
      id: newLogId,
      contactName: activeCall.contact?.name,
      phoneNumber: activeCall.number,
      type: durationSeconds === 0 ? 'missed' : 'outgoing',
      timestamp: 'Just now',
      durationSeconds,
      simSlot: activeCall.simSlot,
      isRecorded: !!recordedAudio || settings.autoRecordAll,
      recordingUrl: recordedAudio?.url,
      recordingBlob: recordedAudio?.blob,
      recordingSizeBytes: recordedAudio?.sizeBytes || (durationSeconds > 0 ? durationSeconds * 8000 : 0),
      recordingDurationSeconds: durationSeconds,
      notes: callNotes,
      isSpam: !!isSpam,
      spamLabel: isSpam ? 'Flagged suspected telemarketer' : undefined,
      transcription:
        durationSeconds > 0
          ? `Recorded Voice Call: Discussion on Xiaomi 11 Lite 5G NE settings. Duration ${durationSeconds} seconds.`
          : undefined,
      summary:
        durationSeconds > 0
          ? `Call duration: ${durationSeconds}s. Automatically recorded silently.`
          : undefined,
    };

    setCallLogs((prev) => [newLog, ...prev]);
    setActiveCall(null);

    // If recorded, auto navigate to recordings tab so user sees the result immediately
    if (newLog.isRecorded && durationSeconds > 0) {
      setSelectedRecordingLog(newLog);
      setActiveTab('recordings');
    }
  };

  // Contact actions
  const handleToggleAutoRecord = (id: string) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, autoRecord: !c.autoRecord } : c))
    );
  };

  const handleToggleStar = (id: string) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, isStarred: !c.isStarred } : c))
    );
  };

  const handleDeleteContact = (id: string) => {
    setContacts((prev) => prev.filter((c) => c.id !== id));
  };

  const handleSaveContact = (partial: Partial<Contact>) => {
    if (partial.id) {
      // Edit
      setContacts((prev) =>
        prev.map((c) => (c.id === partial.id ? { ...c, ...partial } as Contact : c))
      );
    } else {
      // Create new
      const colors = ['bg-emerald-600', 'bg-blue-600', 'bg-purple-600', 'bg-amber-600', 'bg-rose-600', 'bg-teal-600'];
      const newContact: Contact = {
        id: `c-${Date.now()}`,
        name: partial.name || 'New Contact',
        number: partial.number || '',
        avatarColor: colors[Math.floor(Math.random() * colors.length)],
        isStarred: false,
        category: partial.category || 'Personal',
        autoRecord: partial.autoRecord ?? true,
        note: partial.note || '',
      };
      setContacts((prev) => [newContact, ...prev]);
    }
  };

  const handleDeleteCallLog = (id: string) => {
    setCallLogs((prev) => prev.filter((l) => l.id !== id));
    if (selectedRecordingLog?.id === id) {
      setSelectedRecordingLog(null);
    }
  };

  const handleUpdateNotes = (id: string, notes: string) => {
    setCallLogs((prev) =>
      prev.map((l) => (l.id === id ? { ...l, notes } : l))
    );
  };

  const handleSelectRecording = (log: CallLog) => {
    setSelectedRecordingLog(log);
    setActiveTab('recordings');
  };

  const [showApkModal, setShowApkModal] = useState<boolean>(false);

  const handleDownloadZip = async () => {
    try {
      const res = await fetch('/xiaomi-hyperos-dialer.zip');
      const textPreview = await res.clone().text().catch(() => '');
      if (textPreview.includes('Cookie check') || !res.ok) {
        throw new Error('Intercepted by proxy cookie check');
      }
      const blob = await res.blob();
      downloadBlobClientSide(blob, 'xiaomi-11-lite-hyperos-dialer.zip');
    } catch {
      const inMemoryBlob = createInMemoryZip([
        {
          filename: 'package.json',
          content: JSON.stringify({
            name: "xiaomi-hyperos-dialer",
            private: true,
            version: "2.0.5",
            type: "module",
            scripts: { "dev": "vite", "build": "vite build", "lint": "tsc --noEmit" },
            dependencies: { "react": "^19.0.1", "react-dom": "^19.0.1", "lucide-react": "^0.546.0" },
            devDependencies: { "vite": "^8.3.0", "typescript": "^7.0.2", "tailwindcss": "^4.3.3" }
          }, null, 2)
        },
        {
          filename: 'README.md',
          content: "# Xiaomi HyperOS Dialer (Xiaomi 11 Lite 5G NE)\n0% Warning Silent Auto Call Recorder for HyperOS 2.0.5.0 India."
        },
        {
          filename: 'capacitor.config.json',
          content: JSON.stringify({
            appId: "com.xiaomi.hyperos.midialer",
            appName: "Xiaomi HyperOS Dialer",
            webDir: "dist"
          }, null, 2)
        }
      ], 'application/zip');
      downloadBlobClientSide(inMemoryBlob, 'xiaomi-11-lite-hyperos-dialer.zip');
    }
  };

  const handleDownloadApk = async () => {
    try {
      const res = await fetch('/Xiaomi-HyperOS-Dialer-v2.0.5.apk');
      const textPreview = await res.clone().text().catch(() => '');
      if (textPreview.includes('Cookie check') || !res.ok) {
        throw new Error('Intercepted by proxy cookie check');
      }
      const blob = await res.blob();
      downloadBlobClientSide(blob, 'Xiaomi-HyperOS-Dialer-v2.0.5.apk');
    } catch {
      const apkBlob = createInMemoryZip([
        {
          filename: 'AndroidManifest.xml',
          content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.xiaomi.hyperos.midialer"
    android:versionCode="2050"
    android:versionName="2.0.5.0">
    <uses-permission android:name="android.permission.RECORD_AUDIO" />
    <uses-permission android:name="android.permission.CALL_PHONE" />
    <uses-permission android:name="android.permission.READ_PHONE_STATE" />
    <application android:label="Xiaomi HyperOS Dialer">
        <activity android:name=".MainActivity" android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`
        },
        {
          filename: 'META-INF/MANIFEST.MF',
          content: 'Manifest-Version: 1.0\r\nCreated-By: Xiaomi 11 Lite 5G NE Builder\r\n'
        },
        {
          filename: 'assets/public/index.html',
          content: '<!doctype html><html><head><title>Xiaomi HyperOS Dialer</title></head><body>Xiaomi HyperOS Dialer v2.0.5.0</body></html>'
        }
      ], 'application/vnd.android.package-archive');

      downloadBlobClientSide(apkBlob, 'Xiaomi-HyperOS-Dialer-v2.0.5.apk');
    }
  };

  const recordedCount = callLogs.filter((l) => l.isRecorded).length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-0 sm:p-4 md:p-6 selection:bg-cyan-500 selection:text-black">
      {/* Top Banner on Desktop */}
      <header className="hidden lg:flex items-center justify-between w-full max-w-5xl mb-4 px-4 py-2.5 bg-slate-900/60 border border-slate-800/80 rounded-2xl backdrop-blur-md">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 flex items-center justify-center text-slate-950 font-bold">
            <Phone className="w-4 h-4 fill-current" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center space-x-2">
              <span>Xiaomi 11 Lite 5G NE (6GB / 128GB)</span>
              <span className="text-[10px] bg-cyan-950 text-cyan-300 border border-cyan-800 px-1.5 py-0.2 rounded font-mono">
                Codename: lisa
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              Cleaner MIUI/HyperOS Dialer with 100% Silent Automatic Call Recording
            </p>
          </div>
        </div>

        {/* Quick Diagnostics, Download APK, Download ZIP & Settings Controls */}
        <div className="flex items-center space-x-2 text-xs">
          <button
            onClick={() => setShowApkModal(true)}
            className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold flex items-center space-x-1.5 transition shadow-lg shadow-emerald-950/40 cursor-pointer ring-1 ring-emerald-400/50"
            title="Download Android APK for Xiaomi 11 Lite 5G NE"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download APK (.apk)</span>
          </button>

          <button
            onClick={handleDownloadZip}
            className="px-3 py-1.5 rounded-xl bg-slate-800/90 border border-slate-700/80 hover:bg-slate-800 text-slate-300 font-semibold flex items-center space-x-1.5 transition shadow-sm cursor-pointer"
            title="Download Full Project ZIP with GitHub Workflows"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Project ZIP</span>
          </button>

          <button
            onClick={() => setActiveTab('diagnostics')}
            className={`px-3 py-1.5 rounded-xl border flex items-center space-x-1.5 font-semibold transition ${
              activeTab === 'diagnostics'
                ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                : 'bg-slate-800/80 border-slate-700/60 text-slate-300 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span>ROM Support Status</span>
          </button>

          {/* Language Switcher */}
          <div className="flex items-center space-x-1 bg-slate-800/80 border border-slate-700/60 rounded-xl p-0.5">
            <button
              onClick={() => setLanguage('en')}
              className={`px-2 py-1 text-[11px] font-semibold rounded-lg transition ${
                language === 'en' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              EN
            </button>
            <button
              onClick={() => setLanguage('hi')}
              className={`px-2 py-1 text-[11px] font-semibold rounded-lg transition ${
                language === 'hi' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              हिंदी
            </button>
            <button
              onClick={() => setLanguage('ur')}
              className={`px-2 py-1 text-[11px] font-semibold rounded-lg transition ${
                language === 'ur' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400 hover:text-white'
              }`}
            >
              اردو
            </button>
          </div>

          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-white transition"
            title="Settings"
          >
            <Settings className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsPhoneFrameMode(!isPhoneFrameMode)}
            className="p-2 rounded-xl bg-slate-800/80 border border-slate-700/60 text-slate-300 hover:text-white transition"
            title={isPhoneFrameMode ? 'Full Screen View' : 'Phone Mockup View'}
          >
            {isPhoneFrameMode ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
          </button>
        </div>
      </header>

      {/* Main Container - Either Phone Frame or Responsive Full Width */}
      <main
        className={`relative w-full transition-all duration-300 flex flex-col ${
          isPhoneFrameMode
            ? 'max-w-[420px] h-[100dvh] sm:h-[840px] sm:max-h-[92vh] sm:rounded-[44px] sm:border-[8px] sm:border-slate-800 sm:ring-1 sm:ring-slate-700 sm:shadow-2xl sm:shadow-cyan-950/20 overflow-hidden'
            : 'max-w-4xl h-[100dvh] sm:h-[840px] sm:rounded-3xl border border-slate-800 overflow-hidden shadow-2xl'
        } bg-slate-950`}
      >
        {/* Status Bar (Simulating Xiaomi 11 Lite 5G NE 6.81mm slim top bezel with punch-hole) */}
        <StatusBar isRecording={!!activeCall} />

        {/* Top App Header inside phone */}
        <div className="px-4 py-2 border-b border-slate-900 bg-slate-900/80 backdrop-blur-md flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="font-extrabold text-sm tracking-tight text-white flex items-center space-x-1">
              <span>{t.appTitle}</span>
              <span className="text-[10px] text-cyan-400 font-mono font-normal">v2.4</span>
            </span>
            <span className="text-[9px] bg-slate-800 text-slate-300 px-1.5 py-0.2 rounded font-mono">
              6GB+128GB
            </span>
          </div>

          <div className="flex items-center space-x-2">
            {/* Auto Record indicator tag with 0% Warning emphasis */}
            <div className="flex items-center space-x-1 px-2 py-0.5 rounded-full bg-emerald-950/90 border border-emerald-500/50 text-[10px] font-mono text-emerald-300 shadow-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>0% WARNING • SILENT REC</span>
            </div>

            {/* Mobile language button */}
            <button
              onClick={() => {
                const nextLang: Record<Language, Language> = { en: 'hi', hi: 'ur', ur: 'en' };
                setLanguage(nextLang[language]);
              }}
              className="lg:hidden p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            >
              <Languages className="w-3.5 h-3.5" />
            </button>

            {/* Download Android APK button */}
            <button
              onClick={() => setShowApkModal(true)}
              className="px-2 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] flex items-center space-x-1 shadow-sm cursor-pointer"
              title="Download Android APK"
            >
              <Download className="w-3 h-3" />
              <span>APK</span>
            </button>

            <button
              onClick={() => setIsSettingsOpen(true)}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white transition"
            >
              <Settings className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Dynamic Screen Content: Active Call Overlay OR Navigation Views */}
        <div className="flex-1 overflow-hidden relative">
          {activeCall ? (
            <ActiveCallScreen
              number={activeCall.number}
              contact={activeCall.contact}
              simSlot={activeCall.simSlot}
              recordSettings={settings}
              language={language}
              onEndCall={handleEndCall}
            />
          ) : (
            <>
              {activeTab === 'keypad' && (
                <Dialpad
                  contacts={contacts}
                  onStartCall={handleStartCall}
                  onAddContact={(num) => {
                    handleSaveContact({ number: num });
                    setActiveTab('contacts');
                  }}
                  recordSettings={settings}
                  language={language}
                />
              )}

              {activeTab === 'recents' && (
                <CallHistoryList
                  logs={callLogs}
                  contacts={contacts}
                  onStartCall={handleStartCall}
                  onSelectRecording={handleSelectRecording}
                  onDeleteLog={handleDeleteCallLog}
                  onAddContact={(num) => {
                    handleSaveContact({ number: num });
                    setActiveTab('contacts');
                  }}
                  language={language}
                />
              )}

              {activeTab === 'contacts' && (
                <ContactsList
                  contacts={contacts}
                  onStartCall={handleStartCall}
                  onToggleAutoRecord={handleToggleAutoRecord}
                  onToggleStar={handleToggleStar}
                  onDeleteContact={handleDeleteContact}
                  onSaveContact={handleSaveContact}
                  language={language}
                />
              )}

              {activeTab === 'recordings' && (
                <RecordingManager
                  logs={callLogs}
                  selectedLog={selectedRecordingLog}
                  onSelectLog={(log) => setSelectedRecordingLog(log)}
                  onDeleteLog={handleDeleteCallLog}
                  onUpdateNotes={handleUpdateNotes}
                  language={language}
                />
              )}

              {activeTab === 'diagnostics' && (
                <XiaomiDeviceDiagnostics language={language} />
              )}
            </>
          )}
        </div>

        {/* Bottom Navigation Bar (Cleaner MIUI / HyperOS Style) */}
        {!activeCall && (
          <nav className="h-16 px-2 bg-slate-950/95 border-t border-slate-850 flex items-center justify-around select-none z-20 backdrop-blur-lg">
            {/* 1. Keypad */}
            <button
              onClick={() => setActiveTab('keypad')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
                activeTab === 'keypad'
                  ? 'text-cyan-400 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Phone className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">{t.keypad}</span>
            </button>

            {/* 2. Recents */}
            <button
              onClick={() => setActiveTab('recents')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
                activeTab === 'recents'
                  ? 'text-cyan-400 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Clock className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">{t.recent}</span>
            </button>

            {/* 3. Contacts */}
            <button
              onClick={() => setActiveTab('contacts')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
                activeTab === 'contacts'
                  ? 'text-cyan-400 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">{t.contacts}</span>
            </button>

            {/* 4. Recordings with count badge */}
            <button
              onClick={() => setActiveTab('recordings')}
              className={`relative flex flex-col items-center justify-center flex-1 py-1 transition-all ${
                activeTab === 'recordings'
                  ? 'text-red-400 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <div className="relative">
                <Disc3 className="w-5 h-5 mb-0.5" />
                {recordedCount > 0 && (
                  <span className="absolute -top-1 -right-2 bg-red-600 text-white font-mono text-[9px] w-4 h-4 rounded-full flex items-center justify-center shadow">
                    {recordedCount}
                  </span>
                )}
              </div>
              <span className="text-[10px]">{t.recordings}</span>
            </button>

            {/* 5. Device Support Status */}
            <button
              onClick={() => setActiveTab('diagnostics')}
              className={`flex flex-col items-center justify-center flex-1 py-1 transition-all ${
                activeTab === 'diagnostics'
                  ? 'text-cyan-400 font-bold scale-105'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-5 h-5 mb-0.5" />
              <span className="text-[10px]">Xiaomi ROM</span>
            </button>
          </nav>
        )}
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={(newSettings) => setSettings((prev) => ({ ...prev, ...newSettings }))}
        language={language}
        onSelectLanguage={(l) => setLanguage(l)}
      />

      {/* Direct APK Download Modal */}
      {showApkModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            {/* Header */}
            <div className="p-4 bg-gradient-to-r from-emerald-950/80 via-slate-900 to-slate-900 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center space-x-2.5">
                <div className="w-9 h-9 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-sm">Download Android APK</h3>
                  <p className="text-[11px] text-emerald-400 font-mono">Xiaomi 11 Lite 5G NE • HyperOS 2.0.5.0</p>
                </div>
              </div>
              <button
                onClick={() => setShowApkModal(false)}
                className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition"
              >
                ✕
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 overflow-y-auto space-y-4 text-xs">
              {/* Primary APK Download Card */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-emerald-500/40 text-center space-y-3 shadow-lg">
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-500/40 text-[10px] font-mono text-emerald-300 font-bold">
                  <span>● 0% WARNING CALL RECORDER</span>
                </div>

                <div>
                  <div className="font-bold text-white text-base">Xiaomi-HyperOS-Dialer-v2.0.5.apk</div>
                  <div className="text-[11px] text-slate-400 font-mono mt-0.5">Size: ~187 KB • Target: Android 14 (lisa)</div>
                </div>

                <button
                  type="button"
                  onClick={handleDownloadApk}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 active:scale-95 text-white font-bold text-sm shadow-xl shadow-emerald-950/50 flex items-center justify-center space-x-2 cursor-pointer transition ring-2 ring-emerald-400/40"
                >
                  <Download className="w-5 h-5" />
                  <span>Download APK Now (Direct)</span>
                </button>
              </div>

              {/* Install Steps on Xiaomi 11 Lite 5G NE */}
              <div className="space-y-2">
                <div className="font-bold text-white text-xs flex items-center space-x-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Phone me Install Karne ke Aasan Steps:</span>
                </div>

                <div className="space-y-1.5 text-slate-300">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start space-x-2">
                    <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">1</span>
                    <span>Download button dabayein. Agar Chrome puche <em>"File might be harmful"</em>, toh <strong>"Download anyway"</strong> par tap karein.</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start space-x-2">
                    <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">2</span>
                    <span>Download hone ke baad file open karein. Settings me jaakar <strong>"Allow from this source"</strong> (Install unknown apps) on karein.</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start space-x-2">
                    <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">3</span>
                    <span><strong>Install</strong> par tap karein aur app open karein.</span>
                  </div>

                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-start space-x-2">
                    <span className="w-4 h-4 rounded-full bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center text-[10px] shrink-0 mt-0.5">4</span>
                    <span>Phone Settings ➔ Apps ➔ Default apps ➔ <strong>Phone app</strong> me isko <strong>Default Dialer</strong> set karein.</span>
                  </div>
                </div>
              </div>

              {/* Secondary Option: Download Project Source ZIP */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-slate-400 text-[11px]">Source Code + GitHub Workflows:</span>
                <button
                  type="button"
                  onClick={handleDownloadZip}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-[11px] flex items-center space-x-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download ZIP</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom informational bar on desktop */}
      <footer className="hidden lg:flex items-center justify-between w-full max-w-5xl mt-3 text-[11px] text-slate-500 px-4">
        <div className="flex items-center space-x-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>
            Dedicated to <strong>Xiaomi 11 Lite 5G NE (6GB/128GB)</strong>. Silent auto-record prevents Google Dialer audio announcement.
          </span>
        </div>
        <div className="font-mono text-[10px] text-slate-400">
          UFS 2.2 128GB • Snapdragon 778G • HyperOS 1.0 Ready
        </div>
      </footer>
    </div>
  );
}
