/**
 * Client-side in-memory ZIP / APK generator.
 * Zero external network calls -> 100% bypasses Google AI Studio proxy / Cookie Check page!
 * Generates valid ZIP/APK blobs directly in browser memory.
 */

interface ZipEntry {
  filename: string;
  content: string | Uint8Array;
}

export function createInMemoryZip(entries: ZipEntry[], mimeType: string = 'application/zip'): Blob {
  const parts: Uint8Array[] = [];
  const centralDirEntries: Uint8Array[] = [];
  let offset = 0;

  // CRC32 table
  const crcTable = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    }
    crcTable[i] = c;
  }

  function crc32(buf: Uint8Array): number {
    let crc = 0xffffffff;
    for (let i = 0; i < buf.length; i++) {
      crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xff];
    }
    return (crc ^ 0xffffffff) >>> 0;
  }

  const encoder = new TextEncoder();

  for (const entry of entries) {
    const filenameBytes = encoder.encode(entry.filename);
    const contentBytes =
      typeof entry.content === 'string' ? encoder.encode(entry.content) : entry.content;
    const fileCrc = crc32(contentBytes);
    const uncompressedSize = contentBytes.length;
    const compressedSize = uncompressedSize; // Store uncompressed (method 0)

    // Local file header (30 bytes + filename)
    const localHeader = new Uint8Array(30 + filenameBytes.length);
    const lView = new DataView(localHeader.buffer);
    lView.setUint32(0, 0x04034b50, true); // Local header signature
    lView.setUint16(4, 20, true); // Version needed
    lView.setUint16(6, 0, true); // Flags
    lView.setUint16(8, 0, true); // Compression: 0 = Store
    lView.setUint16(10, 0x3000, true); // Time (12:00)
    lView.setUint16(12, 0x542b, true); // Date (2026-10-11)
    lView.setUint32(14, fileCrc, true);
    lView.setUint32(18, compressedSize, true);
    lView.setUint32(22, uncompressedSize, true);
    lView.setUint16(26, filenameBytes.length, true);
    lView.setUint16(28, 0, true); // Extra field len
    localHeader.set(filenameBytes, 30);

    parts.push(localHeader);
    parts.push(contentBytes);

    // Central directory header (46 bytes + filename)
    const cdHeader = new Uint8Array(46 + filenameBytes.length);
    const cdView = new DataView(cdHeader.buffer);
    cdView.setUint32(0, 0x02014b50, true); // Central header signature
    cdView.setUint16(4, 20, true); // Version made by
    cdView.setUint16(6, 20, true); // Version needed
    cdView.setUint16(8, 0, true); // Flags
    cdView.setUint16(10, 0, true); // Compression: 0 = Store
    cdView.setUint16(12, 0x3000, true); // Time
    cdView.setUint16(14, 0x542b, true); // Date
    cdView.setUint32(16, fileCrc, true);
    cdView.setUint32(20, compressedSize, true);
    cdView.setUint32(24, uncompressedSize, true);
    cdView.setUint16(28, filenameBytes.length, true);
    cdView.setUint16(30, 0, true); // Extra field len
    cdView.setUint16(32, 0, true); // Comment len
    cdView.setUint16(34, 0, true); // Disk start
    cdView.setUint16(36, 0, true); // Internal attrs
    cdView.setUint32(38, 0x81a40000, true); // External attrs (-rw-r--r--)
    cdView.setUint32(42, offset, true); // Relative offset of local header
    cdHeader.set(filenameBytes, 46);

    centralDirEntries.push(cdHeader);
    offset += localHeader.length + contentBytes.length;
  }

  // Combine central directory
  let centralDirSize = 0;
  for (const cd of centralDirEntries) {
    centralDirSize += cd.length;
    parts.push(cd);
  }

  // End of central directory record (22 bytes)
  const eocd = new Uint8Array(22);
  const eView = new DataView(eocd.buffer);
  eView.setUint32(0, 0x06054b50, true); // EOCD signature
  eView.setUint16(4, 0, true); // Disk number
  eView.setUint16(6, 0, true); // Disk with central dir
  eView.setUint16(8, entries.length, true); // Entries on this disk
  eView.setUint16(10, entries.length, true); // Total entries
  eView.setUint32(12, centralDirSize, true); // Central dir size
  eView.setUint32(16, offset, true); // Offset of central dir
  eView.setUint16(20, 0, true); // Comment len

  parts.push(eocd);

  return new Blob(parts as BlobPart[], { type: mimeType });
}

export function downloadBlobClientSide(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => {
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }, 1500);
}
