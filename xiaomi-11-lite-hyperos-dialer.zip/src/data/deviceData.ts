import { XiaomiDeviceInfo } from '../types/dialer';

export const XIAOMI_11_LITE_5G_NE_SPECS: XiaomiDeviceInfo = {
  modelName: 'Xiaomi 11 Lite 5G NE',
  marketingName: 'Mi 11 Lite 5G NE (India Edition)',
  codeName: 'lisa',
  processor: 'Qualcomm Snapdragon 778G 5G (6nm TSMC)',
  ramTotalGb: 6,
  ramVirtualGb: 2,
  ramUsedGb: 3.5,
  romTotalGb: 128,
  romUsedGb: 68.2,
  screenSpec: '6.55" Flat AMOLED, 90Hz, 10-bit Dolby Vision, HDR10+, 800 nits',
  weightThickness: '158g / 6.81mm Featherweight Profile',
  currentRomRegion: 'IN',
  androidVersion: 'Android 14 (HyperOS 2.0.5.0)',
  nativeRecordingSupported: true,
  requiresRegionSwitch: false,
};

export interface RomRegionInfo {
  regionCode: string;
  regionName: string;
  romCode: string;
  dialerApp: 'Xiaomi HyperOS Dialer' | 'Google Phone';
  callRecordingStatus: 'Supported (100% Silent Auto-Record)' | 'Google Warning Announcement' | 'Restricted';
  announcementWarning: boolean;
  recommendationRating: number;
  description: string;
  fastbootAvailable: boolean;
}

export const ROM_REGIONS_MATRIX: RomRegionInfo[] = [
  {
    regionCode: 'IN',
    regionName: 'India (HyperOS 2.0.5.0)',
    romCode: 'OS2.0.5.0.UKOINXM (Android 14)',
    dialerApp: 'Xiaomi HyperOS Dialer',
    callRecordingStatus: 'Supported (100% Silent Auto-Record)',
    announcementWarning: false,
    recommendationRating: 5,
    description: 'Aapke phone me HyperOS 2.0.5.0 India build hai. Google dialer ki warning ko bypass karke ye native Xiaomi HyperOS dialer provide karta hai jisme 0% warning sound aur automatic background call recording chalti hai.',
    fastbootAvailable: true,
  },
  {
    regionCode: 'ID',
    regionName: 'Indonesia (Official HyperOS)',
    romCode: 'OS1.0.3.0.UKOIDXM / OS2.0.1.0 (Android 14)',
    dialerApp: 'Xiaomi HyperOS Dialer',
    callRecordingStatus: 'Supported (100% Silent Auto-Record)',
    announcementWarning: false,
    recommendationRating: 5,
    description: 'Original Xiaomi Phone app with unrestricted silent auto call recording, banking apps work 100%.',
    fastbootAvailable: true,
  },
  {
    regionCode: 'TW',
    regionName: 'Taiwan (HyperOS)',
    romCode: 'OS1.0.2.0.UKOTWXM (Android 14)',
    dialerApp: 'Xiaomi HyperOS Dialer',
    callRecordingStatus: 'Supported (100% Silent Auto-Record)',
    announcementWarning: false,
    recommendationRating: 5,
    description: 'Includes native HyperOS dialer with auto call recording.',
    fastbootAvailable: true,
  },
  {
    regionCode: 'GLOBAL',
    regionName: 'Global International',
    romCode: 'OS1.0.4.0.UKOMIXM (Android 14)',
    dialerApp: 'Google Phone',
    callRecordingStatus: 'Google Warning Announcement',
    announcementWarning: true,
    recommendationRating: 2,
    description: 'Ships with Google Dialer. Announces "This call is now being recorded" loudly to the other party.',
    fastbootAvailable: true,
  },
  {
    regionCode: 'EEA',
    regionName: 'Europe EEA',
    romCode: 'OS1.0.5.0.UKOEUXM (Android 14)',
    dialerApp: 'Google Phone',
    callRecordingStatus: 'Google Warning Announcement',
    announcementWarning: true,
    recommendationRating: 2,
    description: 'Subject to strict GDPR/Google regulations. Comes with Google Dialer.',
    fastbootAvailable: true,
  },
  {
    regionCode: 'EU_CUSTOM',
    regionName: 'Xiaomi.eu Community HyperOS',
    romCode: 'xiaomi.eu_multi_LISA_OS2.0 (Android 14)',
    dialerApp: 'Xiaomi HyperOS Dialer',
    callRecordingStatus: 'Supported (100% Silent Auto-Record)',
    announcementWarning: false,
    recommendationRating: 4,
    description: 'Custom community firmware based on China HyperOS with zero bloatware and native recording.',
    fastbootAvailable: false,
  },
];


export const STEP_BY_STEP_GUIDE = [
  {
    step: 1,
    title: 'Unlock Bootloader via Mi Unlock Tool',
    desc: 'Go to Settings > About Phone > Tap "MIUI version" 7 times. Go to Developer Options, enable "OEM Unlocking" & "USB Debugging", link your Mi Account under "Mi Unlock Status", and unlock after 168 hours.',
  },
  {
    step: 2,
    title: 'Download Official Indonesian Fastboot ROM ("lisa")',
    desc: 'Download the official fastboot tgz image for Xiaomi 11 Lite 5G NE Indonesia (IDXM) from official Xiaomi servers (e.g. lisa_id_global_images).',
  },
  {
    step: 3,
    title: 'Flash via Mi Flash Tool with "Clean All"',
    desc: 'Extract ROM, put device into Fastboot mode (Power + Vol Down), connect to PC, open XiaoMiFlash.exe. Select "clean all" (Do NOT select "clean all and lock" if changing regional cross-branch to prevent soft-brick).',
  },
  {
    step: 4,
    title: 'Enable Native Silent Auto-Recording in MIUI Settings',
    desc: 'Open Phone Dialer > Settings (Gear icon) > Call Recording > Enable "Record calls automatically" > Choose "All numbers" or "Selected numbers". Enjoy 100% silent recording without any warning beep!',
  },
  {
    step: 5,
    title: 'MIUI / HyperOS Battery Saver Optimization for 6GB RAM',
    desc: 'For 3rd party dialers like MiDialer Pro: Long-press app icon > App Info > Battery Saver > Choose "No restrictions". Turn ON "Autostart" and lock app in Recent Apps overview.',
  },
];
