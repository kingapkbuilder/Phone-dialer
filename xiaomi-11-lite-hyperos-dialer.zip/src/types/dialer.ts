export type Language = 'en' | 'hi' | 'ur';

export type CallType = 'incoming' | 'outgoing' | 'missed' | 'rejected';

export interface Contact {
  id: string;
  name: string;
  number: string;
  avatarColor: string;
  isStarred?: boolean;
  category?: 'Personal' | 'Work' | 'Family' | 'Other';
  autoRecord?: boolean;
  note?: string;
}

export interface CallLog {
  id: string;
  contactName?: string;
  phoneNumber: string;
  type: CallType;
  timestamp: string; // ISO or formatted
  durationSeconds: number; // 0 for missed
  simSlot: 1 | 2;
  isRecorded: boolean;
  recordingUrl?: string;
  recordingBlob?: Blob;
  recordingSizeBytes?: number;
  recordingDurationSeconds?: number;
  notes?: string;
  isSpam?: boolean;
  spamLabel?: string;
  transcription?: string;
  summary?: string;
}

export interface RecordSettings {
  autoRecordAll: boolean;
  autoRecordUnknown: boolean;
  autoRecordSelectedOnly: boolean;
  selectedContactIds: string[];
  silentMode: boolean; // No sound or warning to other party
  audioFormat: 'aac' | 'wav' | 'webm';
  audioQuality: 'standard' | 'high' | 'ultra'; // 64k, 128k, 256k
  notifyOnCompleted: boolean;
  storageSavingMode: boolean;
  dtmfSound: boolean;
  sim1Carrier: string;
  sim2Carrier: string;
  activeSim: 1 | 2;
}

export interface XiaomiDeviceInfo {
  modelName: string; // "Xiaomi 11 Lite 5G NE"
  marketingName: string; // "Mi 11 Lite 5G NE"
  codeName: string; // "lisa"
  processor: string; // "Qualcomm Snapdragon 778G 5G (6nm)"
  ramTotalGb: number; // 6
  ramVirtualGb: number; // 2 or 3
  ramUsedGb: number; // e.g. 3.4
  romTotalGb: number; // 128
  romUsedGb: number; // e.g. 74.2
  screenSpec: string; // "6.55\" AMOLED 90Hz HDR10+ Dolby Vision"
  weightThickness: string; // "158g / 6.81mm Ultra-Slim"
  currentRomRegion: 'ID' | 'GLOBAL' | 'EEA' | 'IN' | 'TW' | 'EU_CUSTOM';
  androidVersion: 'Android 14 (HyperOS 2.0.5.0)' | 'Android 14 (HyperOS 1.0)' | 'Android 13 (MIUI 14)' | 'Android 12 (MIUI 13)';
  nativeRecordingSupported: boolean;
  requiresRegionSwitch: boolean;
}
