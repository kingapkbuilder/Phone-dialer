# 📱 Xiaomi HyperOS Dialer & 0% Warning Auto Call Recorder
### Optimized for Xiaomi 11 Lite 5G NE (*lisa*) • HyperOS 2.0.5.0 India (Android 14)

![Xiaomi HyperOS](https://img.shields.io/badge/Xiaomi-HyperOS%202.0.5.0-emerald)
![Target Device](https://img.shields.io/badge/Device-Xiaomi%2011%20Lite%205G%20NE-cyan)
![Android Version](https://img.shields.io/badge/Android-14%20(UpsideDownCake)-blue)
![Call Recording](https://img.shields.io/badge/Auto--Record-0%25%20Warning%20(Silent)-success)
![Storage](https://img.shields.io/badge/Storage-128GB%20UFS%202.2-purple)
![RAM](https://img.shields.io/badge/RAM-6GB%20%2B%202GB%20Virtual-orange)

An ultra-clean, authentic **Xiaomi HyperOS Dialer replacement** tailored specifically for the **Xiaomi 11 Lite 5G NE (6GB RAM / 128GB ROM, Codename: lisa)** running **HyperOS 2.0.5.0 India (Android 14)**.

---

## 🌟 Key Features

### 1. 🔇 0% Warning Announcement (100% Silent Call Recording)
* **No Voice Alert:** Completely eliminates Google Dialer's loud *"This call is now being recorded"* voice prompt.
* **No Beep Tones:** Neither caller nor recipient hears any beep or warning audio.
* **Auto Background Trigger:** Calls are recorded automatically in the background without requiring manual button presses.
* **Discrete In-Call REC Badge:** Displays a clean red recording timer only on your screen.

### 2. ⚡ Authentic Xiaomi HyperOS (Android 14) Design
* **Circular Tactile Dialpad:** Large, rounded keys with T9 smart predictive contact search.
* **India Dual SIM Calling Bar:** Dedicated side-by-side calling buttons for:
  * `SIM 1 (Jio 5G / VoNR)`
  * `SIM 2 (Airtel 5G / VoLTE)`
* **In-Call Screen:** Glassmorphism UI with caller profile, mute, keypad, speaker, call notes, and audio recording controls.
* **DTMF Synthesizer:** Authentic dual-tone multifrequency audio generator for dialpad keys.

### 3. 📂 MIUI & HyperOS Standard Storage Integration
* **File Directory:** Formatted according to Xiaomi's native sound recorder structure:
  ```text
  /Internal storage/MIUI/sound_recorder/call_rec/
  ```
* **Integrated Waveform Player:** Playback scrubber, speed control (0.75x, 1x, 1.25x, 1.5x, 2x), and `.wav` export.
* **128GB ROM Telemetry:** Real-time storage estimation (1 hour @ 128kbps AAC ≈ 57.6 MB; holds ~940+ hours).

### 4. 🚀 6GB RAM Background Protection Guide
* MIUI / HyperOS Battery Saver: **"No restrictions"** configuration guide.
* Autostart & Recent Apps lock instructions to prevent Xiaomi's RAM optimizer from killing background recording services.

---

## 🛠️ Project Structure

```text
├── .github/
│       └── main.yml               # All-in-one Build, Lint, ZIP & Deploy Pipeline
├── src/
│   ├── components/
│   │   ├── ActiveCallScreen.tsx   # HyperOS call interface with silent recording
│   │   ├── CallHistoryList.tsx    # Recents log with filters (All, Missed, Recorded)
│   │   ├── ContactsList.tsx       # Contacts manager with auto-record rules
│   │   ├── Dialpad.tsx            # Circular T9 keypad with India dual SIM buttons
│   │   ├── RecordingManager.tsx   # Waveform audio player & MIUI storage tracker
│   │   ├── SettingsModal.tsx      # Dual SIM, audio quality & silent mode toggles
│   │   ├── StatusBar.tsx          # Xiaomi 11 Lite 5G NE top-left punch-hole bar
│   │   └── XiaomiDeviceDiagnostics.tsx # HyperOS 2.0.5.0 India hardware & ROM matrix
│   ├── data/
│   │   ├── defaultContacts.ts     # Initial contacts and recorded calls
│   │   └── deviceData.ts          # Xiaomi 11 Lite 5G NE hardware & ROM matrix
│   ├── types/
│   │   └── dialer.ts              # TypeScript schemas
│   ├── utils/
│   │   ├── audioSynthesizer.ts    # Web Audio API DTMF tone generator
│   │   ├── soundRecorder.ts       # MediaRecorder API with WAV fallback
│   │   └── translations.ts        # Localization (English, Hindi, Urdu)
│   ├── App.tsx                    # Main phone container
│   ├── index.css                  # Tailwind styles
│   └── main.tsx                   # React root
├── index.html                     # Entry HTML
├── package.json                   # Dependencies
├── tsconfig.json                  # TypeScript configuration
└── vite.config.ts                 # Vite bundler configuration
```

---

## 💻 Local Development Setup

### 1. Clone the repository
```bash
git clone https://github.com/<your-username>/xiaomi-11-lite-dialer.git
cd xiaomi-11-lite-dialer
```

### 2. Install dependencies
```bash
npm install
```

### 3. Start local development server
```bash
npm run dev
```
Open `http://localhost:3000` in your web browser or connect via your mobile browser on the same Wi-Fi network.

### 4. Build for production
```bash
npm run build
```
Compiled static assets will be created in the `dist/` directory.

### 5. Run linting checks
```bash
npm run lint
```

---

## 🤖 All-in-One GitHub Actions Workflow (`main.yml`)

This repository uses a single, unified workflow file at `.github/workflows/main.yml`:

* **Triggers:** Automatically on push / pull_request to `main` or `master` (and manual `workflow_dispatch`).
* **Checks:** Sets up Node.js 20, runs TypeScript linting (`npm run lint`), and builds the web app (`npm run build`).
* **Artifacts:** Automatically packages a clean source code ZIP (`xiaomi-hyperos-dialer.zip`) and attaches both the build and ZIP to the workflow run summary for instant download.
* **Deploy:** Deploys automatically to GitHub Pages when merged into `main`.

---

## 📲 How to Wrap as Android APK (Capacitor)

To compile this into a native `.apk` installed directly on your Xiaomi 11 Lite 5G NE:

```bash
# 1. Install Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android

# 2. Initialize Capacitor
npx cap init "MiDialer Pro" "com.xiaomi.hyperos.midialer"

# 3. Add Android platform
npx cap add android

# 4. Build web code & copy to Android
npm run build
npx cap copy

# 5. Open in Android Studio & Generate Signed APK
npx cap open android
```

---

## 📄 License
Apache License 2.0
